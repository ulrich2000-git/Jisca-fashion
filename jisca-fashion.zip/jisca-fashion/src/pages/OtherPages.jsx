import React from 'react';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="about-page">
      <div className="about-hero">
        <div className="container">
          <p className="section-eyebrow">Notre Histoire</p>
          <h1>À Propos de Jisca Fashion</h1>
          <div className="gold-line center" />
        </div>
      </div>

      <section className="about-story section container">
        <div className="story-grid">
          <div className="story-img">
            <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=700&q=80" alt="Notre atelier" />
            <div className="story-img-accent" />
          </div>
          <div className="story-text">
            <p className="section-eyebrow">Notre Mission</p>
            <h2>Célébrer la Mode Africaine</h2>
            <div className="gold-line" />
            <p>Fondée à Cotonou, Jisca Fashion est née d'une passion profonde pour l'élégance africaine et le désir de mettre en valeur le savoir-faire artisanal du Bénin et de l'Afrique de l'Ouest.</p>
            <p>Chaque pièce que nous proposons raconte une histoire — celle des artisans qui la confectionnent avec amour, des tissus qui traversent les générations, et des femmes et hommes qui les portent avec fierté.</p>
            <p>Notre engagement est simple : vous offrir des vêtements et accessoires de qualité exceptionnelle, qui mêlent tradition africaine et modernité contemporaine.</p>
            <div className="about-stats">
              {[['500+', 'Articles en boutique'], ['1000+', 'Clients satisfaits'], ['5+', 'Années d\'expérience'], ['100%', 'Artisanat local']].map(([n, l]) => (
                <div key={n} className="stat">
                  <strong>{n}</strong>
                  <span>{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="values-section">
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '48px' }}>
            <p className="section-eyebrow">Nos Valeurs</p>
            <h2 className="section-title">Ce qui nous guide</h2>
            <div className="gold-line center" />
          </div>
          <div className="values-grid">
            {[
              { icon: '🌿', title: 'Authenticité', desc: 'Des matières authentiques, sourcées directement auprès des producteurs locaux et des artisans traditionnels.' },
              { icon: '✨', title: 'Excellence', desc: 'Chaque article est soigneusement sélectionné ou créé avec les plus hauts standards de qualité.' },
              { icon: '🤝', title: 'Communauté', desc: 'Nous soutenons les artisans et créateurs béninois, contribuant au développement économique local.' },
              { icon: '🌍', title: 'Fierté Africaine', desc: 'Nous célébrons et promouvons le patrimoine culturel africain à travers chaque création.' },
            ].map(v => (
              <div key={v.title} className="value-card">
                <span className="value-icon">{v.icon}</span>
                <h3>{v.title}</h3>
                <p>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <style>{`
        .about-hero {
          background: linear-gradient(135deg, var(--noir) 0%, var(--noir-mid) 100%);
          padding: 140px 0 64px;
          text-align: center;
          color: white;
        }
        .about-hero .section-eyebrow { color: var(--gold); }
        .about-hero h1 { font-size: clamp(36px, 5vw, 60px); font-style: italic; font-weight: 400; }

        .story-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: center; }

        .story-img { position: relative; }
        .story-img img { width: 100%; aspect-ratio: 3/4; object-fit: cover; border-radius: var(--radius-lg); }
        .story-img-accent { position: absolute; top: -16px; left: -16px; right: 16px; bottom: 16px; border: 2px solid var(--gold); border-radius: var(--radius-lg); z-index: -1; opacity: 0.5; }

        .story-text p { font-size: 15px; color: var(--text-secondary); line-height: 1.8; margin-bottom: 16px; }
        .story-text h2 { font-size: clamp(28px, 4vw, 44px); font-style: italic; font-weight: 400; margin-bottom: 4px; }

        .about-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 36px; }
        .stat { padding: 20px; background: white; border: 1px solid var(--border); border-radius: var(--radius-lg); text-align: center; }
        .stat strong { display: block; font-family: var(--font-display); font-size: 36px; font-weight: 600; color: var(--gold); font-style: italic; }
        .stat span { font-size: 12px; color: var(--text-muted); }

        .values-section { background: var(--noir); padding: 96px 0; }
        .values-section .section-eyebrow { color: var(--gold); }
        .values-section .section-title { color: white; }
        .values-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }

        .value-card {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: var(--radius-lg);
          padding: 32px 24px;
          text-align: center;
          transition: var(--transition);
        }
        .value-card:hover { border-color: var(--gold); background: rgba(201,168,76,0.05); }

        .value-icon { font-size: 40px; display: block; margin-bottom: 16px; }
        .value-card h3 { font-family: var(--font-display); font-size: 22px; color: white; font-weight: 400; margin-bottom: 12px; }
        .value-card p { font-size: 14px; color: rgba(255,255,255,0.55); line-height: 1.7; }

        @media (max-width: 1024px) {
          .values-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
          .story-grid { grid-template-columns: 1fr; gap: 40px; }
          .story-img-accent { display: none; }
        }
        @media (max-width: 640px) {
          .values-grid { grid-template-columns: 1fr; }
          .about-stats { grid-template-columns: repeat(2, 1fr); }
        }
      `}</style>
    </div>
  );
}

export function ContactPage() {
  const [form, setForm] = React.useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = React.useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="contact-page">
      <div className="contact-hero">
        <div className="container">
          <p className="section-eyebrow">Nous Contacter</p>
          <h1>Parlons ensemble</h1>
          <div className="gold-line center" />
          <p>Une question ? Un conseil ? Notre équipe est là pour vous.</p>
        </div>
      </div>

      <div className="contact-grid container section">
        <div className="contact-info">
          <h2>Nos Coordonnées</h2>
          <div className="gold-line" />
          <p>Venez nous rendre visite en boutique ou contactez-nous par l'un des moyens ci-dessous.</p>

          <div className="info-items">
            {[
              { icon: <MapPin size={20} />, title: 'Adresse', lines: ['Rue du Commerce', 'Cotonou, Bénin'] },
              { icon: <Phone size={20} />, title: 'Téléphone', lines: ['+229 97 XX XX XX', '+229 96 XX XX XX'] },
              { icon: <Mail size={20} />, title: 'Email', lines: ['contact@jiscafashion.bj', 'commandes@jiscafashion.bj'] },
              { icon: <Clock size={20} />, title: 'Horaires', lines: ['Lundi – Samedi : 08h – 20h', 'Dimanche : 10h – 18h'] },
            ].map(item => (
              <div key={item.title} className="info-item">
                <div className="info-icon">{item.icon}</div>
                <div>
                  <strong>{item.title}</strong>
                  {item.lines.map((l, i) => <p key={i}>{l}</p>)}
                </div>
              </div>
            ))}
          </div>

          <div className="contact-social">
            <p>Suivez-nous</p>
            <div className="social-row">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><Instagram size={20} /></a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><Facebook size={20} /></a>
            </div>
          </div>
        </div>

        <div className="contact-form-wrap">
          {sent ? (
            <div className="form-success">
              <span>✅</span>
              <h3>Message envoyé !</h3>
              <p>Merci de nous avoir contactés. Nous vous répondrons dans les 24 heures.</p>
              <button onClick={() => { setSent(false); setForm({ name: '', email: '', subject: '', message: '' }); }}>
                Envoyer un autre message
              </button>
            </div>
          ) : (
            <form className="contact-form" onSubmit={handleSubmit}>
              <h3>Envoyer un message</h3>
              <div className="cf-row">
                <div className="cf-group">
                  <label>Nom complet *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Votre nom" required />
                </div>
                <div className="cf-group">
                  <label>Email *</label>
                  <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="votre@email.com" required />
                </div>
              </div>
              <div className="cf-group">
                <label>Sujet</label>
                <select value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}>
                  <option value="">Sélectionner un sujet</option>
                  <option>Commande & Livraison</option>
                  <option>Retour & Échange</option>
                  <option>Question sur un produit</option>
                  <option>Partenariat</option>
                  <option>Autre</option>
                </select>
              </div>
              <div className="cf-group">
                <label>Message *</label>
                <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} placeholder="Votre message..." rows={5} required />
              </div>
              <button type="submit" className="btn-send">Envoyer le message</button>
            </form>
          )}
        </div>
      </div>

      <style>{`
        .contact-hero {
          background: linear-gradient(135deg, var(--noir) 0%, var(--noir-mid) 100%);
          padding: 140px 0 64px;
          text-align: center;
          color: white;
        }
        .contact-hero .section-eyebrow { color: var(--gold); }
        .contact-hero h1 { font-size: clamp(36px, 5vw, 60px); font-style: italic; font-weight: 400; margin-bottom: 4px; }
        .contact-hero .gold-line { margin: 16px auto; }
        .contact-hero p { color: rgba(255,255,255,0.6); font-size: 15px; }

        .contact-grid { display: grid; grid-template-columns: 1fr 1.4fr; gap: 60px; align-items: start; }

        .contact-info h2 { font-size: 32px; font-style: italic; font-weight: 400; margin-bottom: 4px; }
        .contact-info > p { font-size: 14px; color: var(--text-secondary); margin: 20px 0 32px; line-height: 1.7; }

        .info-items { display: flex; flex-direction: column; gap: 24px; margin-bottom: 36px; }
        .info-item { display: flex; gap: 16px; align-items: flex-start; }
        .info-icon {
          width: 44px;
          height: 44px;
          background: rgba(201,168,76,0.1);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--gold);
          flex-shrink: 0;
        }
        .info-item strong { display: block; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-primary); margin-bottom: 4px; }
        .info-item p { font-size: 14px; color: var(--text-secondary); line-height: 1.6; }

        .contact-social p { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-muted); margin-bottom: 12px; }
        .social-row { display: flex; gap: 10px; }
        .social-row a { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border: 1px solid var(--border); border-radius: 50%; color: var(--text-secondary); transition: var(--transition); }
        .social-row a:hover { border-color: var(--gold); color: var(--gold); }

        .contact-form-wrap { background: white; border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 40px; }

        .contact-form h3 { font-family: var(--font-display); font-size: 26px; font-weight: 400; margin-bottom: 28px; }

        .cf-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .cf-group { margin-bottom: 20px; }
        .cf-group label { display: block; font-size: 11px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); margin-bottom: 8px; }
        .cf-group input, .cf-group select, .cf-group textarea {
          width: 100%;
          padding: 12px 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 14px;
          font-family: var(--font-body);
          color: var(--text-primary);
          background: var(--cream);
          outline: none;
          transition: var(--transition);
          resize: vertical;
        }
        .cf-group input:focus, .cf-group select:focus, .cf-group textarea:focus { border-color: var(--gold); background: white; box-shadow: 0 0 0 3px rgba(201,168,76,0.1); }

        .btn-send {
          width: 100%;
          padding: 16px;
          background: var(--gold);
          color: white;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          border-radius: var(--radius);
          transition: var(--transition);
          border: none;
        }
        .btn-send:hover { background: var(--gold-dark); transform: translateY(-1px); box-shadow: 0 6px 20px rgba(201,168,76,0.3); }

        .form-success {
          text-align: center;
          padding: 48px 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
        }
        .form-success span { font-size: 56px; }
        .form-success h3 { font-family: var(--font-display); font-size: 28px; font-weight: 400; }
        .form-success p { font-size: 15px; color: var(--text-secondary); max-width: 300px; }
        .form-success button { padding: 12px 24px; border: 1px solid var(--border); border-radius: var(--radius); font-size: 13px; color: var(--text-secondary); transition: var(--transition); background: white; }
        .form-success button:hover { border-color: var(--gold); color: var(--gold); }

        @media (max-width: 768px) {
          .contact-grid { grid-template-columns: 1fr; }
          .cf-row { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
