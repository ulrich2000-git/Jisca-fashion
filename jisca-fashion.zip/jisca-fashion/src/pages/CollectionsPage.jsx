import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { products, formatPrice } from '../data/products';
import ProductCard from '../components/ProductCard';

const collections = [
  {
    id: 'saison',
    title: 'Collection Saison des Pluies',
    subtitle: 'Été 2024',
    desc: 'Des pièces légères et vibrantes pour accueillir la saison avec élégance. Wax, bogolan et coton fin se marient harmonieusement.',
    cover: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200&q=80',
    color: '#1A3A2A',
    accent: '#4CAF50',
    products: [1, 2, 5, 6],
  },
  {
    id: 'ceremonie',
    title: 'Collection Grande Cérémonie',
    subtitle: 'Édition Prestige',
    desc: 'Pour vos mariages, baptêmes et grandes fêtes. Des tenues majestueuses qui vous feront briller lors de chaque événement.',
    cover: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=1200&q=80',
    color: '#3A1A0A',
    accent: '#C9A84C',
    products: [7, 1, 3, 4],
  },
  {
    id: 'quotidien',
    title: 'Collection Au Quotidien',
    subtitle: 'Lifestyle Urbain',
    desc: 'La mode africaine moderne pour tous les jours. Des tenues confortables, stylées et pratiques pour la femme citadine d\'aujourd\'hui.',
    cover: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&q=80',
    color: '#0A1A3A',
    accent: '#5C8FD6',
    products: [2, 6, 8, 5],
  },
];

export default function CollectionsPage() {
  const [activeCollection, setActiveCollection] = useState(null);

  const currentCollection = activeCollection
    ? collections.find(c => c.id === activeCollection)
    : null;

  const collectionProducts = currentCollection
    ? currentCollection.products.map(id => products.find(p => p.id === id)).filter(Boolean)
    : [];

  return (
    <div className="collections-page">
      <div className="coll-hero">
        <div className="container">
          <p className="section-eyebrow">Nos Univers</p>
          <h1>Collections</h1>
          <div className="gold-line center" />
          <p>Chaque collection est une invitation à explorer un pan de l'élégance africaine</p>
        </div>
      </div>

      {/* Collection Cards */}
      <section className="coll-list">
        {collections.map((coll, idx) => (
          <div
            key={coll.id}
            className={`coll-card ${idx % 2 === 1 ? 'reverse' : ''}`}
          >
            <div className="coll-img-wrap">
              <img src={coll.cover} alt={coll.title} />
              <div className="coll-img-overlay" style={{ background: `linear-gradient(${idx % 2 === 1 ? 'to left' : 'to right'}, ${coll.color}CC, transparent)` }} />
            </div>
            <div className="coll-info" style={{ background: coll.color }}>
              <p className="coll-tag" style={{ color: coll.accent }}>✦ {coll.subtitle}</p>
              <h2>{coll.title}</h2>
              <div className="coll-line" style={{ background: coll.accent }} />
              <p className="coll-desc">{coll.desc}</p>
              <div className="coll-actions">
                <button
                  className="coll-btn"
                  style={{ background: coll.accent, borderColor: coll.accent }}
                  onClick={() => setActiveCollection(activeCollection === coll.id ? null : coll.id)}
                >
                  {activeCollection === coll.id ? 'Masquer' : 'Voir la collection'} <ArrowRight size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Expanded collection products */}
      {currentCollection && (
        <section className="coll-products section" id="collection-products">
          <div className="container">
            <div className="section-header">
              <div>
                <p className="section-eyebrow">{currentCollection.subtitle}</p>
                <h2 className="section-title">{currentCollection.title}</h2>
                <div className="gold-line" />
              </div>
              <button className="close-coll" onClick={() => setActiveCollection(null)}>
                × Fermer
              </button>
            </div>
            <div className="products-grid-4">
              {collectionProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: '40px' }}>
              <Link to="/boutique" className="cta-primary">
                Voir toute la boutique <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Lookbook Section */}
      <section className="lookbook section">
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '48px' }}>
            <p className="section-eyebrow">Inspirations</p>
            <h2 className="section-title">Notre Lookbook</h2>
            <div className="gold-line center" />
            <p className="look-sub">Laissez-vous inspirer par nos mises en scène</p>
          </div>
          <div className="lookbook-grid">
            {[
              { img: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600&q=80', size: 'tall' },
              { img: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80', size: 'normal' },
              { img: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80', size: 'normal' },
              { img: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&q=80', size: 'wide' },
              { img: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&q=80', size: 'normal' },
            ].map((item, i) => (
              <div key={i} className={`look-item ${item.size}`}>
                <img src={item.img} alt={`Look ${i + 1}`} />
                <div className="look-overlay">
                  <Link to="/boutique" className="look-cta">Voir les articles</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="coll-cta">
        <div className="container">
          <div className="cta-inner">
            <div>
              <p className="section-eyebrow">Envie de plus ?</p>
              <h2>Explorez toute notre boutique</h2>
              <p>Plus de 500 articles disponibles, avec de nouvelles arrivées chaque semaine.</p>
            </div>
            <Link to="/boutique" className="cta-primary">
              Accéder à la boutique <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      <style>{`
        .coll-hero {
          background: linear-gradient(135deg, var(--noir) 0%, #2C1810 100%);
          padding: 140px 0 64px;
          text-align: center;
          color: white;
        }
        .coll-hero .section-eyebrow { color: var(--gold); }
        .coll-hero h1 { font-size: clamp(48px, 7vw, 80px); font-style: italic; font-weight: 300; }
        .coll-hero .gold-line { margin: 16px auto; }
        .coll-hero p { color: rgba(255,255,255,0.6); font-size: 16px; }

        .coll-list { display: flex; flex-direction: column; }

        .coll-card {
          display: grid;
          grid-template-columns: 1fr 1fr;
          min-height: 520px;
        }
        .coll-card.reverse { direction: rtl; }
        .coll-card.reverse > * { direction: ltr; }

        .coll-img-wrap {
          position: relative;
          overflow: hidden;
        }
        .coll-img-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.8s cubic-bezier(0.4,0,0.2,1);
        }
        .coll-card:hover .coll-img-wrap img { transform: scale(1.04); }
        .coll-img-overlay {
          position: absolute;
          inset: 0;
          pointer-events: none;
        }

        .coll-info {
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 72px 64px;
          color: white;
        }

        .coll-tag {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          margin-bottom: 16px;
        }

        .coll-info h2 {
          font-size: clamp(28px, 3.5vw, 46px);
          font-weight: 300;
          font-style: italic;
          color: white;
          margin-bottom: 8px;
          line-height: 1.1;
        }

        .coll-line { width: 48px; height: 2px; margin: 20px 0; }

        .coll-desc {
          font-size: 15px;
          line-height: 1.8;
          color: rgba(255,255,255,0.65);
          max-width: 380px;
          margin-bottom: 36px;
        }

        .coll-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 13px 28px;
          border: 2px solid;
          border-radius: var(--radius);
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.07em;
          color: white;
          transition: var(--transition);
        }
        .coll-btn:hover { opacity: 0.85; transform: translateX(4px); }

        .coll-actions { display: flex; gap: 16px; align-items: center; }

        /* Collection products */
        .coll-products { background: var(--cream-dark); }
        .section-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 40px; }
        .section-eyebrow { font-size: 11px; font-weight: 600; letter-spacing: 0.2em; text-transform: uppercase; color: var(--gold); margin-bottom: 8px; }
        .section-title { font-size: clamp(28px, 4vw, 42px); font-weight: 400; font-style: italic; }

        .products-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }

        .close-coll {
          padding: 10px 20px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 13px;
          color: var(--text-secondary);
          background: white;
          transition: var(--transition);
        }
        .close-coll:hover { border-color: var(--gold); color: var(--gold); }

        .cta-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 15px 32px;
          background: var(--gold);
          color: white;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border-radius: var(--radius);
          transition: var(--transition);
          border: 2px solid var(--gold);
        }
        .cta-primary:hover { background: var(--gold-dark); border-color: var(--gold-dark); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(201,168,76,0.35); }

        /* Lookbook */
        .lookbook { background: var(--cream); }
        .look-sub { color: var(--text-muted); font-size: 15px; margin-top: 8px; }

        .lookbook-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          grid-template-rows: auto;
          gap: 16px;
        }

        .look-item {
          position: relative;
          overflow: hidden;
          border-radius: var(--radius-lg);
          cursor: pointer;
        }

        .look-item img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.6s cubic-bezier(0.4,0,0.2,1);
          min-height: 240px;
        }

        .look-item.tall { grid-row: span 2; }
        .look-item.tall img { min-height: 496px; }
        .look-item.wide { grid-column: span 2; }

        .look-item:hover img { transform: scale(1.06); }

        .look-overlay {
          position: absolute;
          inset: 0;
          background: rgba(10,8,6,0);
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.4s ease;
        }

        .look-item:hover .look-overlay { background: rgba(10,8,6,0.45); }

        .look-cta {
          padding: 12px 24px;
          background: white;
          color: var(--noir);
          font-size: 13px;
          font-weight: 600;
          border-radius: var(--radius);
          opacity: 0;
          transform: translateY(10px);
          transition: var(--transition);
        }
        .look-item:hover .look-cta { opacity: 1; transform: translateY(0); }

        /* CTA section */
        .coll-cta {
          background: var(--noir);
          padding: 80px 0;
        }

        .cta-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 40px;
        }

        .coll-cta .section-eyebrow { color: var(--gold); }
        .coll-cta h2 { font-size: clamp(28px, 4vw, 44px); font-style: italic; font-weight: 300; color: white; margin-bottom: 12px; }
        .coll-cta p { color: rgba(255,255,255,0.55); font-size: 15px; max-width: 400px; }

        @media (max-width: 1024px) {
          .products-grid-4 { grid-template-columns: repeat(2, 1fr); }
          .lookbook-grid { grid-template-columns: repeat(2, 1fr); }
          .look-item.tall { grid-row: span 1; }
          .look-item.tall img { min-height: 280px; }
        }

        @media (max-width: 768px) {
          .coll-card { grid-template-columns: 1fr; min-height: auto; }
          .coll-card.reverse { direction: ltr; }
          .coll-img-wrap { min-height: 320px; }
          .coll-info { padding: 48px 32px; }
          .cta-inner { flex-direction: column; text-align: center; }
        }

        @media (max-width: 640px) {
          .lookbook-grid { grid-template-columns: 1fr 1fr; }
          .look-item.wide { grid-column: span 1; }
          .products-grid-4 { grid-template-columns: repeat(2, 1fr); gap: 12px; }
        }
      `}</style>
    </div>
  );
}
