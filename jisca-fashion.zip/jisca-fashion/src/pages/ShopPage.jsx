import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X } from 'lucide-react';
import { products, categories, formatPrice } from '../data/products';
import ProductCard from '../components/ProductCard';

export default function ShopPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [sort, setSort] = useState('default');
  const [priceRange, setPriceRange] = useState([0, 100000]);

  const activeCat = searchParams.get('cat') || 'all';

  const filtered = useMemo(() => {
    let list = [...products];
    if (activeCat !== 'all') list = list.filter(p => p.category === activeCat);
    list = list.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
    else if (sort === 'rating') list.sort((a, b) => b.rating - a.rating);
    return list;
  }, [activeCat, sort, priceRange]);

  return (
    <div className="shop-page">
      {/* Page Header */}
      <div className="shop-hero">
        <div className="container">
          <p className="section-eyebrow">Notre Boutique</p>
          <h1>Toutes nos Collections</h1>
          <div className="gold-line" />
          <p>Découvrez {products.length} articles sélectionnés avec soin pour vous</p>
        </div>
      </div>

      <div className="shop-layout container">
        {/* Sidebar */}
        <aside className={`shop-sidebar ${filtersOpen ? 'open' : ''}`}>
          <div className="sidebar-header">
            <h3>Filtres</h3>
            <button className="sidebar-close" onClick={() => setFiltersOpen(false)}><X size={18} /></button>
          </div>

          {/* Categories */}
          <div className="filter-group">
            <h4>Catégories</h4>
            <ul className="cat-filter-list">
              {categories.map(cat => (
                <li key={cat.id}>
                  <button
                    className={`cat-filter-btn ${activeCat === cat.id ? 'active' : ''}`}
                    onClick={() => {
                      setSearchParams(cat.id === 'all' ? {} : { cat: cat.id });
                      setFiltersOpen(false);
                    }}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.label}</span>
                    <span className="cat-count">
                      {cat.id === 'all' ? products.length : products.filter(p => p.category === cat.id).length}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Price */}
          <div className="filter-group">
            <h4>Prix</h4>
            <div className="price-inputs">
              <div className="price-input">
                <label>Min</label>
                <input
                  type="number"
                  value={priceRange[0]}
                  onChange={e => setPriceRange([+e.target.value, priceRange[1]])}
                  min={0}
                  step={1000}
                />
              </div>
              <span className="price-sep">–</span>
              <div className="price-input">
                <label>Max</label>
                <input
                  type="number"
                  value={priceRange[1]}
                  onChange={e => setPriceRange([priceRange[0], +e.target.value])}
                  min={0}
                  step={1000}
                />
              </div>
            </div>
            <p className="price-hint">{formatPrice(priceRange[0])} – {formatPrice(priceRange[1])}</p>
          </div>

          {/* Stock */}
          <div className="filter-group">
            <h4>Disponibilité</h4>
            <label className="check-label">
              <input type="checkbox" defaultChecked />
              <span>En stock ({products.filter(p => p.inStock).length})</span>
            </label>
          </div>
        </aside>

        {filtersOpen && <div className="sidebar-overlay" onClick={() => setFiltersOpen(false)} />}

        {/* Main */}
        <main className="shop-main">
          <div className="shop-toolbar">
            <button className="filter-toggle" onClick={() => setFiltersOpen(true)}>
              <SlidersHorizontal size={16} />
              Filtres
            </button>
            <p className="results-count">{filtered.length} produit{filtered.length !== 1 ? 's' : ''}</p>
            <select className="sort-select" value={sort} onChange={e => setSort(e.target.value)}>
              <option value="default">Tri par défaut</option>
              <option value="price-asc">Prix croissant</option>
              <option value="price-desc">Prix décroissant</option>
              <option value="rating">Mieux notés</option>
            </select>
          </div>

          {filtered.length === 0 ? (
            <div className="no-results">
              <p>Aucun produit ne correspond à votre recherche.</p>
              <button onClick={() => { setSearchParams({}); setPriceRange([0, 100000]); }}>
                Réinitialiser les filtres
              </button>
            </div>
          ) : (
            <div className="shop-grid">
              {filtered.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </main>
      </div>

      <style>{`
        .shop-hero {
          background: linear-gradient(135deg, var(--noir) 0%, var(--noir-mid) 100%);
          padding: 140px 0 64px;
          text-align: center;
          color: white;
        }
        .shop-hero .section-eyebrow { color: var(--gold); }
        .shop-hero h1 { font-size: clamp(36px, 5vw, 60px); font-style: italic; margin-bottom: 4px; }
        .shop-hero .gold-line { margin: 16px auto; }
        .shop-hero p { color: rgba(255,255,255,0.6); font-size: 15px; }

        .shop-layout {
          display: grid;
          grid-template-columns: 260px 1fr;
          gap: 40px;
          padding-top: 48px;
          padding-bottom: 80px;
          align-items: start;
        }

        .shop-sidebar {
          position: sticky;
          top: 100px;
          background: white;
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 24px;
        }

        .sidebar-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border);
        }
        .sidebar-header h3 { font-family: var(--font-display); font-size: 20px; font-weight: 500; }
        .sidebar-close { display: none; color: var(--text-muted); padding: 4px; border-radius: 4px; }
        .sidebar-close:hover { background: var(--cream-dark); }

        .filter-group {
          margin-bottom: 28px;
          padding-bottom: 28px;
          border-bottom: 1px solid var(--border);
        }
        .filter-group:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .filter-group h4 { font-size: 11px; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase; color: var(--text-muted); margin-bottom: 14px; }

        .cat-filter-list { list-style: none; display: flex; flex-direction: column; gap: 2px; }

        .cat-filter-btn {
          display: flex;
          align-items: center;
          gap: 10px;
          width: 100%;
          padding: 10px 12px;
          border-radius: var(--radius);
          font-size: 14px;
          color: var(--text-secondary);
          transition: var(--transition);
          text-align: left;
        }
        .cat-filter-btn:hover { background: var(--cream-dark); color: var(--text-primary); }
        .cat-filter-btn.active { background: rgba(201,168,76,0.1); color: var(--gold); font-weight: 600; }
        .cat-count { margin-left: auto; font-size: 11px; color: var(--text-muted); background: var(--cream-dark); padding: 2px 8px; border-radius: 10px; }
        .cat-filter-btn.active .cat-count { background: rgba(201,168,76,0.15); color: var(--gold); }

        .price-inputs { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
        .price-input { flex: 1; }
        .price-input label { display: block; font-size: 10px; color: var(--text-muted); margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.1em; }
        .price-input input {
          width: 100%;
          padding: 8px 10px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 13px;
          outline: none;
          background: var(--cream);
          font-family: var(--font-body);
        }
        .price-input input:focus { border-color: var(--gold); }
        .price-sep { color: var(--text-muted); font-size: 16px; padding-top: 18px; flex-shrink: 0; }
        .price-hint { font-size: 12px; color: var(--gold-dark); font-weight: 500; }

        .check-label { display: flex; align-items: center; gap: 8px; font-size: 14px; color: var(--text-secondary); cursor: pointer; }
        .check-label input { accent-color: var(--gold); width: 16px; height: 16px; }

        .shop-main { min-width: 0; }

        .shop-toolbar {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 28px;
          padding-bottom: 20px;
          border-bottom: 1px solid var(--border);
        }

        .filter-toggle {
          display: none;
          align-items: center;
          gap: 8px;
          padding: 10px 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 13px;
          font-weight: 500;
          color: var(--text-secondary);
          transition: var(--transition);
        }
        .filter-toggle:hover { border-color: var(--gold); color: var(--gold); }

        .results-count { font-size: 13px; color: var(--text-muted); flex: 1; }

        .sort-select {
          padding: 10px 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 13px;
          font-family: var(--font-body);
          color: var(--text-secondary);
          background: white;
          outline: none;
          cursor: pointer;
        }
        .sort-select:focus { border-color: var(--gold); }

        .shop-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
        }

        .no-results {
          text-align: center;
          padding: 80px 0;
          color: var(--text-muted);
        }
        .no-results p { font-size: 16px; margin-bottom: 16px; }
        .no-results button {
          padding: 12px 24px;
          background: var(--gold);
          color: white;
          border-radius: var(--radius);
          font-size: 13px;
          font-weight: 600;
          transition: var(--transition);
        }
        .no-results button:hover { background: var(--gold-dark); }

        .sidebar-overlay { display: none; }

        @media (max-width: 1024px) {
          .shop-layout { grid-template-columns: 220px 1fr; gap: 28px; }
          .shop-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
          .shop-layout { grid-template-columns: 1fr; }
          .filter-toggle { display: flex; }
          .shop-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 300px;
            z-index: 1100;
            transform: translateX(-100%);
            transition: transform 0.35s ease;
            overflow-y: auto;
            border-radius: 0;
          }
          .shop-sidebar.open { transform: translateX(0); }
          .sidebar-close { display: flex; }
          .sidebar-overlay { display: block; position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 1099; }
        }

        @media (max-width: 480px) {
          .shop-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
        }
      `}</style>
    </div>
  );
}
