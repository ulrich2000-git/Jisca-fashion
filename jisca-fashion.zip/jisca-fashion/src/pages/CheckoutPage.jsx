import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowLeft, Lock } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../data/products';
import toast from 'react-hot-toast';

export default function CheckoutPage() {
  const { items, totalPrice, dispatch } = useCart();
  const [step, setStep] = useState(1); // 1: info, 2: livraison, 3: paiement, 4: confirm
  const [form, setForm] = useState({
    nom: '', prenom: '', email: '', telephone: '',
    adresse: '', ville: 'Cotonou', quartier: '',
    livraison: 'standard',
    paiement: 'mobile_money',
    mobile_number: '',
  });

  const shippingCost = form.livraison === 'express' ? 3000 : form.livraison === 'standard' ? 1500 : 0;
  const total = totalPrice + shippingCost;

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    toast.success('Commande passée avec succès !', { icon: '🎉', duration: 4000, style: { fontFamily: 'DM Sans, sans-serif' } });
    dispatch({ type: 'CLEAR_CART' });
    setStep(4);
  };

  if (items.length === 0 && step !== 4) {
    return (
      <div className="checkout-empty">
        <h2>Votre panier est vide</h2>
        <Link to="/boutique" className="btn-gold-link"><ArrowLeft size={16} /> Continuer mes achats</Link>
        <style>{`.checkout-empty { text-align: center; padding: 200px 24px; } .checkout-empty h2 { font-family: var(--font-display); font-size: 32px; margin-bottom: 20px; } .btn-gold-link { display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: var(--gold); color: white; border-radius: var(--radius); font-size: 14px; font-weight: 600; }`}</style>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <div className="checkout-hero">
        <div className="container">
          <h1>Finaliser ma commande</h1>
          <div className="steps">
            {['Informations', 'Livraison', 'Paiement'].map((s, i) => (
              <React.Fragment key={s}>
                <div className={`step ${step > i + 1 ? 'done' : step === i + 1 ? 'active' : ''}`}>
                  <span className="step-num">{step > i + 1 ? <CheckCircle size={14} /> : i + 1}</span>
                  <span>{s}</span>
                </div>
                {i < 2 && <div className={`step-line ${step > i + 1 ? 'done' : ''}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {step === 4 ? (
        <div className="confirm-screen container">
          <div className="confirm-icon"><CheckCircle size={56} /></div>
          <h2>Commande confirmée !</h2>
          <p>Merci pour votre commande. Vous recevrez une confirmation par SMS/email sous peu.</p>
          <p className="confirm-ref">Référence : <strong>#JF-{Math.random().toString(36).substr(2,8).toUpperCase()}</strong></p>
          <Link to="/" className="btn-go-home">Retour à l'accueil</Link>
        </div>
      ) : (
        <div className="checkout-grid container">
          <div className="checkout-form">
            {/* Step 1 */}
            {step === 1 && (
              <div className="form-section">
                <h3>Vos informations</h3>
                <div className="form-row">
                  <div className="form-group">
                    <label>Prénom *</label>
                    <input value={form.prenom} onChange={e => update('prenom', e.target.value)} placeholder="Votre prénom" />
                  </div>
                  <div className="form-group">
                    <label>Nom *</label>
                    <input value={form.nom} onChange={e => update('nom', e.target.value)} placeholder="Votre nom" />
                  </div>
                </div>
                <div className="form-group">
                  <label>Email *</label>
                  <input type="email" value={form.email} onChange={e => update('email', e.target.value)} placeholder="votre@email.com" />
                </div>
                <div className="form-group">
                  <label>Téléphone *</label>
                  <input value={form.telephone} onChange={e => update('telephone', e.target.value)} placeholder="+229 XX XX XX XX" />
                </div>
                <button
                  className="btn-next"
                  onClick={() => {
                    if (!form.prenom || !form.nom || !form.email || !form.telephone) { toast.error('Veuillez remplir tous les champs'); return; }
                    setStep(2);
                  }}
                >
                  Continuer vers la livraison
                </button>
              </div>
            )}

            {/* Step 2 */}
            {step === 2 && (
              <div className="form-section">
                <h3>Adresse de livraison</h3>
                <div className="form-group">
                  <label>Ville *</label>
                  <select value={form.ville} onChange={e => update('ville', e.target.value)}>
                    {['Cotonou', 'Porto-Novo', 'Abomey-Calavi', 'Parakou', 'Bohicon', 'Natitingou', 'Autre'].map(v => (
                      <option key={v}>{v}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Quartier *</label>
                  <input value={form.quartier} onChange={e => update('quartier', e.target.value)} placeholder="Votre quartier" />
                </div>
                <div className="form-group">
                  <label>Adresse complète *</label>
                  <input value={form.adresse} onChange={e => update('adresse', e.target.value)} placeholder="Rue, numéro, repères..." />
                </div>

                <div className="shipping-options">
                  <h4>Mode de livraison</h4>
                  {[
                    { id: 'standard', label: 'Standard', delay: '24–48h', price: 1500 },
                    { id: 'express', label: 'Express', delay: 'Même jour', price: 3000 },
                    { id: 'pickup', label: 'Retrait en boutique', delay: 'Gratuit', price: 0 },
                  ].map(opt => (
                    <label key={opt.id} className={`shipping-opt ${form.livraison === opt.id ? 'active' : ''}`}>
                      <input type="radio" name="livraison" value={opt.id} checked={form.livraison === opt.id} onChange={e => update('livraison', e.target.value)} />
                      <div className="shipping-opt-info">
                        <strong>{opt.label}</strong>
                        <span>{opt.delay}</span>
                      </div>
                      <span className="shipping-price">{opt.price === 0 ? 'Gratuit' : formatPrice(opt.price)}</span>
                    </label>
                  ))}
                </div>

                <div className="form-nav">
                  <button className="btn-back-step" onClick={() => setStep(1)}><ArrowLeft size={14} /> Retour</button>
                  <button className="btn-next" onClick={() => {
                    if (!form.adresse || !form.quartier) { toast.error('Veuillez remplir l\'adresse'); return; }
                    setStep(3);
                  }}>
                    Continuer vers le paiement
                  </button>
                </div>
              </div>
            )}

            {/* Step 3 */}
            {step === 3 && (
              <div className="form-section">
                <h3>Mode de paiement</h3>
                <div className="payment-options">
                  {[
                    { id: 'mobile_money', label: 'Mobile Money', sub: 'MTN MoMo, Moov Money', icon: '📱' },
                    { id: 'cash', label: 'Paiement à la livraison', sub: 'Cash uniquement', icon: '💵' },
                    { id: 'wave', label: 'Wave', sub: 'Transfert Wave', icon: '🌊' },
                  ].map(opt => (
                    <label key={opt.id} className={`payment-opt ${form.paiement === opt.id ? 'active' : ''}`}>
                      <input type="radio" name="paiement" value={opt.id} checked={form.paiement === opt.id} onChange={e => update('paiement', e.target.value)} />
                      <span className="pay-icon">{opt.icon}</span>
                      <div>
                        <strong>{opt.label}</strong>
                        <span>{opt.sub}</span>
                      </div>
                    </label>
                  ))}
                </div>

                {(form.paiement === 'mobile_money' || form.paiement === 'wave') && (
                  <div className="form-group">
                    <label>Numéro Mobile Money / Wave *</label>
                    <input value={form.mobile_number} onChange={e => update('mobile_number', e.target.value)} placeholder="+229 XX XX XX XX" />
                  </div>
                )}

                <div className="security-note">
                  <Lock size={14} />
                  <span>Vos données sont sécurisées et protégées</span>
                </div>

                <div className="form-nav">
                  <button className="btn-back-step" onClick={() => setStep(2)}><ArrowLeft size={14} /> Retour</button>
                  <button className="btn-confirm" onClick={handleSubmit}>
                    Confirmer ma commande — {formatPrice(total)}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="order-summary">
            <h3>Récapitulatif</h3>
            <div className="summary-items">
              {items.map((item, i) => (
                <div key={i} className="summary-item">
                  <img src={item.image} alt={item.name} />
                  <div>
                    <p>{item.name}</p>
                    <span>{item.selectedSize} · {item.selectedColor} · ×{item.quantity}</span>
                  </div>
                  <strong>{formatPrice(item.price * item.quantity)}</strong>
                </div>
              ))}
            </div>
            <div className="summary-totals">
              <div className="summary-row"><span>Sous-total</span><span>{formatPrice(totalPrice)}</span></div>
              <div className="summary-row"><span>Livraison</span><span>{shippingCost === 0 ? 'Gratuit' : formatPrice(shippingCost)}</span></div>
              <div className="summary-row total"><span>Total</span><strong>{formatPrice(total)}</strong></div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .checkout-page { padding-bottom: 80px; min-height: 100vh; }

        .checkout-hero {
          background: linear-gradient(135deg, var(--noir) 0%, var(--noir-mid) 100%);
          padding: 120px 0 48px;
          text-align: center;
          color: white;
        }
        .checkout-hero h1 { font-size: 40px; font-style: italic; font-weight: 400; margin-bottom: 32px; }

        .steps { display: flex; align-items: center; justify-content: center; gap: 0; }

        .step { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 500; color: rgba(255,255,255,0.4); }
        .step.active { color: white; }
        .step.done { color: var(--gold); }

        .step-num {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: rgba(255,255,255,0.15);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 700;
        }
        .step.active .step-num { background: var(--gold); color: white; }
        .step.done .step-num { background: rgba(201,168,76,0.2); color: var(--gold); }

        .step-line { width: 60px; height: 1px; background: rgba(255,255,255,0.15); margin: 0 12px; }
        .step-line.done { background: var(--gold); }

        .checkout-grid {
          display: grid;
          grid-template-columns: 1fr 400px;
          gap: 40px;
          padding-top: 48px;
        }

        .checkout-form { }

        .form-section { background: white; border-radius: var(--radius-lg); padding: 36px; border: 1px solid var(--border); }
        .form-section h3 { font-family: var(--font-display); font-size: 26px; font-weight: 400; margin-bottom: 28px; }

        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text-muted); margin-bottom: 8px; }
        .form-group input, .form-group select {
          width: 100%;
          padding: 12px 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 14px;
          font-family: var(--font-body);
          color: var(--text-primary);
          background: var(--cream);
          outline: none;
          transition: var(--transition);
        }
        .form-group input:focus, .form-group select:focus { border-color: var(--gold); background: white; box-shadow: 0 0 0 3px rgba(201,168,76,0.1); }

        .shipping-options { margin: 24px 0; }
        .shipping-options h4 { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-muted); margin-bottom: 12px; }

        .shipping-opt {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          cursor: pointer;
          margin-bottom: 8px;
          transition: var(--transition);
        }
        .shipping-opt:hover { border-color: var(--gold); }
        .shipping-opt.active { border-color: var(--gold); background: rgba(201,168,76,0.05); }
        .shipping-opt input { accent-color: var(--gold); }
        .shipping-opt-info { flex: 1; }
        .shipping-opt-info strong { display: block; font-size: 14px; }
        .shipping-opt-info span { font-size: 12px; color: var(--text-muted); }
        .shipping-price { font-size: 14px; font-weight: 600; color: var(--gold-dark); }

        .payment-options { margin-bottom: 24px; }
        .payment-opt {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          cursor: pointer;
          margin-bottom: 8px;
          transition: var(--transition);
        }
        .payment-opt:hover { border-color: var(--gold); }
        .payment-opt.active { border-color: var(--gold); background: rgba(201,168,76,0.05); }
        .payment-opt input { accent-color: var(--gold); }
        .pay-icon { font-size: 24px; }
        .payment-opt div { flex: 1; }
        .payment-opt div strong { display: block; font-size: 14px; }
        .payment-opt div span { font-size: 12px; color: var(--text-muted); }

        .security-note { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--text-muted); margin-bottom: 24px; }
        .security-note svg { color: var(--gold); }

        .form-nav { display: flex; gap: 12px; align-items: center; margin-top: 8px; }
        .btn-back-step { display: flex; align-items: center; gap: 6px; padding: 12px 16px; border: 1px solid var(--border); border-radius: var(--radius); font-size: 13px; color: var(--text-secondary); transition: var(--transition); background: white; }
        .btn-back-step:hover { border-color: var(--gold); color: var(--gold); }

        .btn-next {
          flex: 1;
          padding: 15px 24px;
          background: var(--gold);
          color: white;
          font-size: 14px;
          font-weight: 600;
          border-radius: var(--radius);
          transition: var(--transition);
          border: none;
        }
        .btn-next:hover { background: var(--gold-dark); transform: translateY(-1px); box-shadow: 0 4px 16px rgba(201,168,76,0.3); }

        .btn-confirm {
          flex: 1;
          padding: 15px 24px;
          background: var(--noir);
          color: white;
          font-size: 14px;
          font-weight: 600;
          border-radius: var(--radius);
          transition: var(--transition);
          border: none;
        }
        .btn-confirm:hover { background: var(--noir-mid); transform: translateY(-1px); }

        .order-summary {
          background: white;
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 28px;
          position: sticky;
          top: 100px;
          align-self: start;
        }
        .order-summary h3 { font-family: var(--font-display); font-size: 22px; font-weight: 400; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border); }

        .summary-items { display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px; }

        .summary-item { display: flex; align-items: center; gap: 12px; }
        .summary-item img { width: 52px; height: 60px; object-fit: cover; border-radius: var(--radius); }
        .summary-item div { flex: 1; min-width: 0; }
        .summary-item p { font-size: 13px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .summary-item span { font-size: 11px; color: var(--text-muted); }
        .summary-item strong { font-size: 13px; color: var(--gold-dark); flex-shrink: 0; }

        .summary-totals { border-top: 1px solid var(--border); padding-top: 16px; display: flex; flex-direction: column; gap: 10px; }
        .summary-row { display: flex; justify-content: space-between; font-size: 14px; color: var(--text-secondary); }
        .summary-row.total { font-size: 17px; color: var(--text-primary); font-weight: 600; border-top: 1px solid var(--border); padding-top: 12px; margin-top: 4px; }
        .summary-row.total strong { color: var(--gold-dark); }

        /* Confirmation */
        .confirm-screen { text-align: center; padding: 80px 0; }
        .confirm-icon { width: 80px; height: 80px; background: rgba(201,168,76,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--gold); margin: 0 auto 24px; }
        .confirm-screen h2 { font-family: var(--font-display); font-size: 40px; font-weight: 400; font-style: italic; margin-bottom: 16px; }
        .confirm-screen p { font-size: 16px; color: var(--text-secondary); max-width: 440px; margin: 0 auto 12px; }
        .confirm-ref { font-size: 14px; color: var(--text-muted) !important; margin-bottom: 32px !important; }
        .confirm-ref strong { color: var(--gold-dark); font-family: monospace; }
        .btn-go-home { display: inline-block; padding: 14px 32px; background: var(--gold); color: white; font-size: 14px; font-weight: 600; border-radius: var(--radius); transition: var(--transition); }
        .btn-go-home:hover { background: var(--gold-dark); }

        @media (max-width: 1024px) {
          .checkout-grid { grid-template-columns: 1fr; }
          .order-summary { position: static; }
        }
        @media (max-width: 640px) {
          .form-row { grid-template-columns: 1fr; }
          .form-section { padding: 24px 20px; }
          .steps { gap: 0; }
          .step span:not(.step-num) { display: none; }
          .step-line { width: 32px; }
        }
      `}</style>
    </div>
  );
}
