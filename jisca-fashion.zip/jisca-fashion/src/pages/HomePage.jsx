import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronDown, Sparkles, Truck, Shield, RefreshCw, Star } from 'lucide-react';
import { products, testimonials, categories, formatPrice } from '../data/products';
import ProductCard from '../components/ProductCard';

const heroSlides = [
  {
    title: 'L\'Élégance Africaine',
    subtitle: 'Nouvelle Collection 2024',
    desc: 'Découvrez nos créations exclusives inspirées des richesses culturelles du Bénin et de l\'Afrique de l\'Ouest.',
    bg: 'linear-gradient(135deg, #0A0806 0%, #2C1810 50%, #0A0806 100%)',
    img: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&q=80',
    cta: 'Découvrir la collection',
    link: '/collections',
  },
  {
    title: 'Pagne & Wax',
    subtitle: 'Tissus Authentiques',
    desc: 'Des tissus wax sélectionnés avec soin, des couleurs vibrantes qui racontent l\'histoire de nos cultures.',
    bg: 'linear-gradient(135deg, #1A0A00 0%, #3D1F00 50%, #1A0A00 100%)',
    img: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=800&q=80',
    cta: 'Explorer',
    link: '/boutique?cat=pagne',
  },
];

export default function HomePage() {
  const [slide, setSlide] = useState(0);
  const featured = products.filter(p => p.featured);
  const newArrivals = products.slice(0, 4);

  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % heroSlides.length), 6000);
    return () => clearInterval(t);
  }, []);

  const current = heroSlides[slide];

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero" style={{ background: current.bg }}>
        <div className="hero-img-wrap">
          <img src={current.img} alt="Hero" className="hero-img" key={slide} />
          <div className="hero-img-overlay" />
        </div>

        <div className="hero-content container">
          <div className="hero-text" key={`text-${slide}`}>
            <p className="hero-subtitle">{current.subtitle}</p>
            <h1 className="hero-title">{current.title}</h1>
            <div className="gold-line" />
            <p className="hero-desc">{current.desc}</p>
            <div className="hero-ctas">
              <Link to={current.link} className="cta-primary">
                {current.cta} <ArrowRight size={18} />
              </Link>
              <Link to="/boutique" className="cta-secondary">
                Toute la boutique
              </Link>
            </div>
          </div>
        </div>

        <div className="hero-dots">
          {heroSlides.map((_, i) => (
            <button key={i} className={`dot ${i === slide ? 'active' : ''}`} onClick={() => setSlide(i)} />
          ))}
        </div>

        <a href="#categories" className="hero-scroll">
          <ChevronDown size={20} />
        </a>
      </section>

      {/* Categories Bar */}
      <section id="categories" className="cat-strip">
        <div className="container">
          <div className="cat-list">
            {categories.slice(1).map(cat => (
              <Link key={cat.id} to={`/boutique?cat=${cat.id}`} className="cat-chip">
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features container">
        {[
          { icon: <Truck size={24} />, title: 'Livraison Rapide', desc: 'Livraison partout au Bénin sous 24–48h' },
          { icon: <Shield size={24} />, title: 'Qualité Garantie', desc: 'Tissus authentiques et artisanat de qualité' },
          { icon: <RefreshCw size={24} />, title: 'Retours Faciles', desc: 'Retour gratuit sous 7 jours' },
          { icon: <Sparkles size={24} />, title: 'Pièces Exclusives', desc: 'Collections uniques et éditions limitées' },
        ].map((f, i) => (
          <div className="feature-card" key={i}>
            <div className="feature-icon">{f.icon}</div>
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </div>
        ))}
      </section>

      {/* Featured Products */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <p className="section-eyebrow">Nos Coups de Cœur</p>
              <h2 className="section-title">Sélection Vedette</h2>
              <div className="gold-line" />
            </div>
            <Link to="/boutique" className="see-all">
              Tout voir <ArrowRight size={16} />
            </Link>
          </div>
          <div className="products-grid">
            {featured.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="promo-banner">
        <div className="promo-content container">
          <div className="promo-text">
            <p className="promo-tag">Édition Limitée</p>
            <h2>Robe Kente Ceremonie</h2>
            <p className="promo-desc">Une pièce majestueuse pour vos grandes occasions. Disponible en quantité limitée.</p>
            <div className="promo-price">
              <span>À partir de</span>
              <strong>{formatPrice(72000)}</strong>
            </div>
            <Link to="/produit/7" className="cta-primary">
              Voir la pièce <ArrowRight size={18} />
            </Link>
          </div>
          <div className="promo-img-wrap">
            <img src="https://images.unsplash.com/photo-1562572159-4efc207f5aff?w=800&q=80" alt="Robe Kente" />
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <p className="section-eyebrow">Dernières Arrivées</p>
              <h2 className="section-title">Nouveautés</h2>
              <div className="gold-line" />
            </div>
            <Link to="/boutique" className="see-all">
              Voir tout <ArrowRight size={16} />
            </Link>
          </div>
          <div className="products-grid">
            {newArrivals.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="testimonials-section">
        <div className="container">
          <div className="testi-header">
            <p className="section-eyebrow">Avis Clients</p>
            <h2 className="section-title">Ce qu'ils disent</h2>
            <div className="gold-line center" />
          </div>
          <div className="testi-grid">
            {testimonials.map(t => (
              <div key={t.id} className="testi-card">
                <div className="testi-stars">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={14} fill="#C9A84C" stroke="#C9A84C" />
                  ))}
                </div>
                <p className="testi-text">"{t.text}"</p>
                <div className="testi-author">
                  <img src={t.avatar} alt={t.name} />
                  <div>
                    <strong>{t.name}</strong>
                    <span>{t.location} · {t.product}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <style>{`
        /* Hero */
        .hero {
          position: relative;
          min-height: 100vh;
          display: flex;
          align-items: center;
          overflow: hidden;
        }

        .hero-img-wrap {
          position: absolute;
          inset: 0;
        }

        .hero-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          animation: fadeIn 1s ease;
        }

        .hero-img-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(to right, rgba(10,8,6,0.85) 0%, rgba(10,8,6,0.4) 60%, rgba(10,8,6,0.2) 100%);
        }

        .hero-content {
          position: relative;
          z-index: 1;
          padding-top: 100px;
          padding-bottom: 80px;
        }

        .hero-text {
          max-width: 580px;
          animation: fadeUp 0.8s ease both;
        }

        .hero-subtitle {
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--gold);
          margin-bottom: 16px;
        }

        .hero-title {
          font-size: clamp(48px, 7vw, 88px);
          font-weight: 300;
          color: white;
          line-height: 1;
          margin-bottom: 4px;
          font-style: italic;
        }

        .hero-desc {
          color: rgba(255,255,255,0.75);
          font-size: 16px;
          line-height: 1.7;
          max-width: 440px;
          margin: 20px 0 36px;
        }

        .hero-ctas {
          display: flex;
          gap: 16px;
          flex-wrap: wrap;
        }

        .cta-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 15px 32px;
          background: var(--gold);
          color: white;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border-radius: var(--radius);
          transition: var(--transition);
          border: 2px solid var(--gold);
        }
        .cta-primary:hover { background: var(--gold-dark); border-color: var(--gold-dark); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(201,168,76,0.35); }

        .cta-secondary {
          display: inline-flex;
          align-items: center;
          padding: 15px 32px;
          background: transparent;
          color: white;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border-radius: var(--radius);
          border: 2px solid rgba(255,255,255,0.4);
          transition: var(--transition);
        }
        .cta-secondary:hover { border-color: white; background: rgba(255,255,255,0.1); }

        .hero-dots {
          position: absolute;
          bottom: 40px;
          left: 50%;
          transform: translateX(-50%);
          display: flex;
          gap: 8px;
          z-index: 2;
        }

        .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: rgba(255,255,255,0.3);
          transition: var(--transition);
          border: none;
        }
        .dot.active { background: var(--gold); transform: scale(1.3); }

        .hero-scroll {
          position: absolute;
          bottom: 36px;
          right: 40px;
          width: 44px;
          height: 44px;
          border: 1px solid rgba(255,255,255,0.3);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          z-index: 2;
          animation: bounce 2s infinite;
        }

        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(6px); }
        }

        /* Cat Strip */
        .cat-strip {
          background: white;
          border-bottom: 1px solid var(--border);
          padding: 20px 0;
        }

        .cat-list {
          display: flex;
          gap: 12px;
          overflow-x: auto;
          scrollbar-width: none;
          padding-bottom: 4px;
        }
        .cat-list::-webkit-scrollbar { display: none; }

        .cat-chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          background: var(--cream);
          border: 1px solid var(--border);
          border-radius: 40px;
          font-size: 13px;
          font-weight: 500;
          color: var(--text-secondary);
          white-space: nowrap;
          transition: var(--transition);
        }
        .cat-chip:hover {
          background: var(--gold);
          border-color: var(--gold);
          color: white;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(201,168,76,0.25);
        }

        /* Features */
        .features {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 24px;
          padding: 64px 24px;
        }

        .feature-card {
          text-align: center;
          padding: 32px 20px;
          border-radius: var(--radius-lg);
          border: 1px solid var(--border);
          background: white;
          transition: var(--transition);
        }
        .feature-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-gold); border-color: var(--gold); }

        .feature-icon {
          width: 56px;
          height: 56px;
          background: rgba(201, 168, 76, 0.1);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--gold);
          margin: 0 auto 16px;
        }

        .feature-card h3 {
          font-family: var(--font-display);
          font-size: 18px;
          font-weight: 500;
          margin-bottom: 8px;
        }

        .feature-card p {
          font-size: 13px;
          color: var(--text-muted);
          line-height: 1.6;
        }

        /* Section header */
        .section-header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          margin-bottom: 40px;
        }

        .section-eyebrow {
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--gold);
          margin-bottom: 8px;
        }

        .section-title {
          font-size: clamp(28px, 4vw, 42px);
          font-weight: 400;
          font-style: italic;
          color: var(--text-primary);
        }

        .see-all {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.06em;
          color: var(--gold);
          text-transform: uppercase;
          transition: var(--transition);
          padding-bottom: 8px;
        }
        .see-all:hover { gap: 10px; }

        /* Products grid */
        .products-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 24px;
        }

        /* Promo Banner */
        .promo-banner {
          background: var(--noir);
          overflow: hidden;
        }

        .promo-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          align-items: center;
          min-height: 500px;
        }

        .promo-text {
          padding: 80px 40px 80px 0;
          color: white;
        }

        .promo-tag {
          display: inline-block;
          padding: 6px 14px;
          border: 1px solid var(--gold);
          color: var(--gold);
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          border-radius: 20px;
          margin-bottom: 20px;
        }

        .promo-text h2 {
          font-size: clamp(32px, 4vw, 52px);
          font-weight: 400;
          font-style: italic;
          margin-bottom: 16px;
          line-height: 1.1;
        }

        .promo-desc {
          color: rgba(255,255,255,0.65);
          font-size: 15px;
          line-height: 1.7;
          margin-bottom: 28px;
          max-width: 400px;
        }

        .promo-price {
          display: flex;
          align-items: baseline;
          gap: 12px;
          margin-bottom: 32px;
        }

        .promo-price span {
          font-size: 13px;
          color: rgba(255,255,255,0.5);
        }

        .promo-price strong {
          font-family: var(--font-display);
          font-size: 36px;
          font-weight: 400;
          color: var(--gold);
        }

        .promo-img-wrap {
          height: 100%;
          min-height: 500px;
          overflow: hidden;
        }

        .promo-img-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.8s ease;
        }
        .promo-img-wrap:hover img { transform: scale(1.03); }

        /* Testimonials */
        .testimonials-section {
          background: var(--cream-dark);
          padding: 96px 0;
        }

        .testi-header {
          text-align: center;
          margin-bottom: 56px;
        }

        .testi-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
        }

        .testi-card {
          background: white;
          border-radius: var(--radius-lg);
          padding: 32px;
          border: 1px solid var(--border);
          transition: var(--transition);
        }
        .testi-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-dark); }

        .testi-stars { display: flex; gap: 3px; margin-bottom: 16px; }

        .testi-text {
          font-size: 15px;
          line-height: 1.7;
          color: var(--text-secondary);
          font-style: italic;
          margin-bottom: 24px;
        }

        .testi-author {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .testi-author img {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid var(--gold);
        }

        .testi-author strong { display: block; font-size: 14px; font-weight: 600; }
        .testi-author span { font-size: 11px; color: var(--text-muted); }

        @media (max-width: 1024px) {
          .features { grid-template-columns: repeat(2, 1fr); }
          .products-grid { grid-template-columns: repeat(2, 1fr); }
          .testi-grid { grid-template-columns: 1fr 1fr; }
        }

        @media (max-width: 768px) {
          .promo-content { grid-template-columns: 1fr; }
          .promo-text { padding: 48px 0; }
          .promo-img-wrap { min-height: 300px; }
          .section-header { flex-direction: column; align-items: flex-start; gap: 16px; }
        }

        @media (max-width: 640px) {
          .features { grid-template-columns: 1fr; }
          .products-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
          .testi-grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
