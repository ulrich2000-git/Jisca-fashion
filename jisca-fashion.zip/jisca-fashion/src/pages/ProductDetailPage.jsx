import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingBag, Heart, ArrowLeft, Star, Truck, Shield, ChevronDown, Share2 } from 'lucide-react';
import { products, formatPrice } from '../data/products';
import { useCart } from '../context/CartContext';
import ProductCard from '../components/ProductCard';
import toast from 'react-hot-toast';

export default function ProductDetailPage({ onCartOpen }) {
  const { id } = useParams();
  const product = products.find(p => p.id === +id);
  const { dispatch } = useCart();

  const [selectedImg, setSelectedImg] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [qty, setQty] = useState(1);
  const [wished, setWished] = useState(false);
  const [faqOpen, setFaqOpen] = useState(null);

  if (!product) {
    return (
      <div className="not-found">
        <h2>Produit introuvable</h2>
        <Link to="/boutique" className="btn-back"><ArrowLeft size={16} /> Retour à la boutique</Link>
      </div>
    );
  }

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const addToCart = () => {
    if (!selectedSize) { toast.error('Veuillez sélectionner une taille'); return; }
    if (!selectedColor) { toast.error('Veuillez sélectionner une couleur'); return; }
    for (let i = 0; i < qty; i++) {
      dispatch({ type: 'ADD_ITEM', payload: { ...product, selectedSize, selectedColor } });
    }
    toast.success(`${product.name} ajouté au panier !`, { icon: '🛍️', style: { fontFamily: 'DM Sans, sans-serif', fontSize: '14px' } });
    onCartOpen?.();
  };

  const faqs = [
    { q: 'Quels sont les délais de livraison ?', a: 'Nous livrons partout au Bénin sous 24 à 48h. Pour les autres pays d\'Afrique de l\'Ouest, comptez 3 à 5 jours ouvrés.' },
    { q: 'Comment prendre ses mesures ?', a: 'Consultez notre guide des tailles disponible sur la page boutique. En cas de doute, contactez-nous directement.' },
    { q: 'Puis-je retourner un article ?', a: 'Oui, vous avez 7 jours à compter de la réception pour retourner un article dans son état d\'origine.' },
  ];

  const discount = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : null;

  return (
    <div className="product-detail">
      <div className="container">
        <div className="breadcrumb">
          <Link to="/">Accueil</Link> / <Link to="/boutique">Boutique</Link> / <span>{product.name}</span>
        </div>

        <div className="detail-grid">
          {/* Images */}
          <div className="detail-images">
            <div className="img-thumbs">
              {product.images.map((img, i) => (
                <button key={i} className={`thumb ${selectedImg === i ? 'active' : ''}`} onClick={() => setSelectedImg(i)}>
                  <img src={img} alt={`${product.name} ${i + 1}`} />
                </button>
              ))}
            </div>
            <div className="img-main">
              <img src={product.images[selectedImg]} alt={product.name} />
              {product.badge && <span className="detail-badge">{product.badge}</span>}
              {discount && <span className="detail-badge discount">-{discount}%</span>}
            </div>
          </div>

          {/* Info */}
          <div className="detail-info">
            <div className="detail-rating">
              <div className="stars">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} fill={i < Math.floor(product.rating) ? '#C9A84C' : 'none'} stroke="#C9A84C" />
                ))}
              </div>
              <span>{product.rating} ({product.reviews} avis)</span>
            </div>

            <h1 className="detail-name">{product.name}</h1>

            <div className="detail-pricing">
              <span className="detail-price">{formatPrice(product.price)}</span>
              {product.originalPrice && <span className="detail-original">{formatPrice(product.originalPrice)}</span>}
              {discount && <span className="detail-discount">-{discount}%</span>}
            </div>

            <p className="detail-desc">{product.description}</p>

            {/* Colors */}
            <div className="option-group">
              <label>Couleur : <strong>{selectedColor || 'Choisir'}</strong></label>
              <div className="option-list">
                {product.colors.map(c => (
                  <button
                    key={c}
                    className={`option-btn ${selectedColor === c ? 'active' : ''}`}
                    onClick={() => setSelectedColor(c)}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div className="option-group">
              <label>Taille : <strong>{selectedSize || 'Choisir'}</strong></label>
              <div className="option-list">
                {product.sizes.map(s => (
                  <button
                    key={s}
                    className={`option-btn size-btn ${selectedSize === s ? 'active' : ''}`}
                    onClick={() => setSelectedSize(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Qty */}
            <div className="qty-group">
              <label>Quantité</label>
              <div className="qty-ctrl">
                <button onClick={() => setQty(Math.max(1, qty - 1))}>−</button>
                <span>{qty}</span>
                <button onClick={() => setQty(qty + 1)}>+</button>
              </div>
            </div>

            {/* Actions */}
            <div className="detail-actions">
              <button
                className="btn-add-cart"
                onClick={addToCart}
                disabled={!product.inStock}
              >
                <ShoppingBag size={18} />
                {product.inStock ? 'Ajouter au panier' : 'Rupture de stock'}
              </button>
              <button className={`btn-wish ${wished ? 'active' : ''}`} onClick={() => setWished(!wished)}>
                <Heart size={18} fill={wished ? 'currentColor' : 'none'} />
              </button>
              <button className="btn-share">
                <Share2 size={18} />
              </button>
            </div>

            {/* Trust */}
            <div className="trust-badges">
              <div className="trust-item"><Truck size={16} /><span>Livraison rapide au Bénin</span></div>
              <div className="trust-item"><Shield size={16} /><span>Qualité garantie</span></div>
            </div>

            {/* FAQ */}
            <div className="faqs">
              {faqs.map((f, i) => (
                <div key={i} className="faq-item">
                  <button className="faq-q" onClick={() => setFaqOpen(faqOpen === i ? null : i)}>
                    <span>{f.q}</span>
                    <ChevronDown size={16} className={faqOpen === i ? 'rotated' : ''} />
                  </button>
                  {faqOpen === i && <p className="faq-a">{f.a}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="related-section">
            <div className="section-header">
              <div>
                <p className="section-eyebrow">Dans la même catégorie</p>
                <h2 className="section-title">Produits similaires</h2>
                <div className="gold-line" />
              </div>
            </div>
            <div className="related-grid">
              {related.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>

      <style>{`
        .product-detail { padding-top: 100px; padding-bottom: 80px; }

        .not-found { text-align: center; padding: 200px 24px; }
        .not-found h2 { font-family: var(--font-display); font-size: 32px; margin-bottom: 20px; }
        .btn-back { display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: var(--gold); color: white; border-radius: var(--radius); font-size: 14px; font-weight: 600; }

        .breadcrumb {
          display: flex;
          gap: 8px;
          align-items: center;
          font-size: 12px;
          color: var(--text-muted);
          margin-bottom: 40px;
          padding-top: 20px;
        }
        .breadcrumb a:hover { color: var(--gold); }
        .breadcrumb span { color: var(--text-secondary); }

        .detail-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 60px;
          align-items: start;
          margin-bottom: 80px;
        }

        .detail-images {
          display: flex;
          gap: 12px;
          position: sticky;
          top: 100px;
        }

        .img-thumbs {
          display: flex;
          flex-direction: column;
          gap: 8px;
          width: 72px;
        }

        .thumb {
          width: 72px;
          height: 80px;
          border: 2px solid transparent;
          border-radius: var(--radius);
          overflow: hidden;
          transition: var(--transition);
        }
        .thumb img { width: 100%; height: 100%; object-fit: cover; }
        .thumb.active, .thumb:hover { border-color: var(--gold); }

        .img-main {
          flex: 1;
          aspect-ratio: 3/4;
          border-radius: var(--radius-lg);
          overflow: hidden;
          position: relative;
          background: var(--cream-dark);
        }
        .img-main img { width: 100%; height: 100%; object-fit: cover; }

        .detail-badge {
          position: absolute;
          top: 16px;
          left: 16px;
          padding: 6px 12px;
          background: var(--noir);
          color: white;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          border-radius: 20px;
        }
        .detail-badge.discount { left: auto; right: 16px; background: var(--gold); }

        .detail-info { padding-top: 8px; }

        .detail-rating { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
        .detail-rating .stars { display: flex; gap: 3px; }
        .detail-rating span { font-size: 13px; color: var(--text-muted); }

        .detail-name { font-size: clamp(28px, 4vw, 44px); font-weight: 400; font-style: italic; margin-bottom: 16px; line-height: 1.1; }

        .detail-pricing { display: flex; align-items: baseline; gap: 12px; margin-bottom: 20px; }
        .detail-price { font-size: 28px; font-weight: 600; color: var(--gold-dark); }
        .detail-original { font-size: 18px; color: var(--text-muted); text-decoration: line-through; }
        .detail-discount { padding: 4px 10px; background: rgba(201,168,76,0.1); color: var(--gold-dark); font-size: 13px; font-weight: 700; border-radius: 20px; }

        .detail-desc { font-size: 15px; color: var(--text-secondary); line-height: 1.7; margin-bottom: 28px; }

        .option-group { margin-bottom: 24px; }
        .option-group label { font-size: 13px; color: var(--text-muted); display: block; margin-bottom: 10px; }
        .option-group label strong { color: var(--text-primary); }

        .option-list { display: flex; flex-wrap: wrap; gap: 8px; }

        .option-btn {
          padding: 8px 16px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-size: 13px;
          color: var(--text-secondary);
          transition: var(--transition);
          background: white;
        }
        .option-btn:hover { border-color: var(--gold); color: var(--gold); }
        .option-btn.active { border-color: var(--gold); background: var(--gold); color: white; font-weight: 600; }

        .size-btn { min-width: 44px; text-align: center; }

        .qty-group { margin-bottom: 28px; }
        .qty-group label { font-size: 13px; color: var(--text-muted); display: block; margin-bottom: 10px; }

        .qty-ctrl {
          display: inline-flex;
          align-items: center;
          gap: 0;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
        }
        .qty-ctrl button {
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          color: var(--text-secondary);
          background: white;
          transition: var(--transition);
        }
        .qty-ctrl button:hover { background: var(--cream-dark); color: var(--gold); }
        .qty-ctrl span { padding: 0 20px; font-size: 16px; font-weight: 600; border-left: 1px solid var(--border); border-right: 1px solid var(--border); line-height: 44px; min-width: 56px; text-align: center; }

        .detail-actions { display: flex; gap: 10px; margin-bottom: 24px; }

        .btn-add-cart {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 16px 24px;
          background: var(--gold);
          color: white;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 0.06em;
          border-radius: var(--radius);
          transition: var(--transition);
          border: 2px solid var(--gold);
        }
        .btn-add-cart:hover:not(:disabled) { background: var(--gold-dark); border-color: var(--gold-dark); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(201,168,76,0.35); }
        .btn-add-cart:disabled { opacity: 0.5; cursor: not-allowed; }

        .btn-wish, .btn-share {
          width: 52px;
          height: 52px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid var(--border);
          border-radius: var(--radius);
          color: var(--text-muted);
          transition: var(--transition);
          background: white;
        }
        .btn-wish:hover, .btn-share:hover { border-color: var(--gold); color: var(--gold); }
        .btn-wish.active { border-color: #e53e3e; color: #e53e3e; }

        .trust-badges {
          display: flex;
          gap: 24px;
          padding: 16px 0;
          border-top: 1px solid var(--border);
          border-bottom: 1px solid var(--border);
          margin-bottom: 28px;
        }
        .trust-item { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary); }
        .trust-item svg { color: var(--gold); }

        .faqs { display: flex; flex-direction: column; gap: 2px; }

        .faq-item { border-bottom: 1px solid var(--border); }

        .faq-q {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          padding: 16px 0;
          font-size: 14px;
          color: var(--text-primary);
          font-weight: 500;
          text-align: left;
          gap: 16px;
        }
        .faq-q:hover { color: var(--gold); }
        .faq-q svg { flex-shrink: 0; transition: transform 0.3s ease; }
        .faq-q svg.rotated { transform: rotate(180deg); }

        .faq-a { font-size: 13px; color: var(--text-secondary); line-height: 1.7; padding-bottom: 16px; }

        .related-section { padding-top: 60px; border-top: 1px solid var(--border); }

        .section-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 40px; }
        .section-eyebrow { font-size: 11px; font-weight: 600; letter-spacing: 0.2em; text-transform: uppercase; color: var(--gold); margin-bottom: 8px; }
        .section-title { font-size: clamp(24px, 3vw, 36px); font-weight: 400; font-style: italic; }

        .related-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }

        @media (max-width: 1024px) {
          .detail-grid { gap: 40px; }
          .related-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
          .detail-grid { grid-template-columns: 1fr; gap: 32px; }
          .detail-images { position: static; }
        }

        @media (max-width: 480px) {
          .related-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
          .img-thumbs { display: none; }
        }
      `}</style>
    </div>
  );
}
