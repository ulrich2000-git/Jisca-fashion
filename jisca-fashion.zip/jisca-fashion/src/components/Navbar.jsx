import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Search, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Navbar({ onCartOpen, onSearchOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { totalItems } = useCart();
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'Accueil' },
    { to: '/boutique', label: 'Boutique' },
    { to: '/collections', label: 'Collections' },
    { to: '/a-propos', label: 'À Propos' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <>
      <nav className={`navbar ${scrolled || !isHome ? 'scrolled' : ''}`}>
        <div className="nav-inner container">
          <button className="nav-mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          <Link to="/" className="nav-logo">
            <span className="logo-j">J</span>
            <span className="logo-text">isca</span>
            <span className="logo-fashion">FASHION</span>
          </Link>

          <ul className="nav-links">
            {navLinks.map(link => (
              <li key={link.to}>
                <Link
                  to={link.to}
                  className={`nav-link ${location.pathname === link.to ? 'active' : ''}`}
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="nav-actions">
            <button className="nav-icon-btn" onClick={onSearchOpen} title="Rechercher">
              <Search size={20} />
            </button>
            <Link to="/favoris" className="nav-icon-btn" title="Favoris">
              <Heart size={20} />
            </Link>
            <button className="nav-icon-btn cart-btn" onClick={onCartOpen} title="Panier">
              <ShoppingBag size={20} />
              {totalItems > 0 && (
                <span className="cart-badge">{totalItems}</span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${mobileOpen ? 'open' : ''}`}>
        <div className="mobile-menu-inner">
          <div className="mobile-logo">
            <span className="logo-j">J</span>
            <span className="logo-text">isca</span>
            <span className="logo-fashion">FASHION</span>
          </div>
          <ul>
            {navLinks.map(link => (
              <li key={link.to}>
                <Link to={link.to} className={`mobile-link ${location.pathname === link.to ? 'active' : ''}`}>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mobile-footer">
            <p>📍 Cotonou, Bénin</p>
            <p>📞 +229 97 XX XX XX</p>
          </div>
        </div>
      </div>
      {mobileOpen && <div className="mobile-overlay" onClick={() => setMobileOpen(false)} />}

      <style>{`
        .navbar {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 1000;
          transition: var(--transition);
          padding: 20px 0;
          background: transparent;
        }

        .navbar.scrolled {
          background: rgba(250, 247, 242, 0.96);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          padding: 12px 0;
          box-shadow: 0 1px 0 var(--border), 0 4px 24px rgba(0,0,0,0.06);
        }

        .nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
        }

        .nav-logo {
          display: flex;
          align-items: baseline;
          gap: 2px;
          flex-shrink: 0;
        }

        .logo-j {
          font-family: var(--font-display);
          font-size: 32px;
          font-weight: 700;
          color: var(--gold);
          line-height: 1;
          font-style: italic;
        }

        .logo-text {
          font-family: var(--font-display);
          font-size: 24px;
          font-weight: 400;
          color: var(--noir);
          font-style: italic;
        }

        .logo-fashion {
          font-family: var(--font-body);
          font-size: 9px;
          font-weight: 600;
          letter-spacing: 0.25em;
          color: var(--gold);
          margin-left: 6px;
          text-transform: uppercase;
        }

        .navbar:not(.scrolled) .logo-text,
        .navbar:not(.scrolled) .logo-fashion { color: var(--white); }

        .nav-links {
          display: flex;
          list-style: none;
          gap: 36px;
          flex: 1;
          justify-content: center;
        }

        .nav-link {
          font-size: 13px;
          font-weight: 500;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--noir);
          position: relative;
          padding-bottom: 4px;
        }

        .nav-link::after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 0;
          right: 100%;
          height: 1px;
          background: var(--gold);
          transition: right 0.3s ease;
        }

        .nav-link:hover::after, .nav-link.active::after { right: 0; }
        .nav-link.active { color: var(--gold); }

        .navbar:not(.scrolled) .nav-link { color: rgba(255,255,255,0.9); }
        .navbar:not(.scrolled) .nav-link:hover,
        .navbar:not(.scrolled) .nav-link.active { color: var(--gold-light); }

        .nav-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-shrink: 0;
        }

        .nav-icon-btn {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: var(--noir);
          transition: var(--transition);
          position: relative;
        }

        .nav-icon-btn:hover {
          background: rgba(201, 168, 76, 0.1);
          color: var(--gold);
        }

        .navbar:not(.scrolled) .nav-icon-btn { color: white; }
        .navbar:not(.scrolled) .nav-icon-btn:hover { background: rgba(255,255,255,0.15); color: var(--gold-light); }

        .cart-badge {
          position: absolute;
          top: 4px;
          right: 4px;
          width: 18px;
          height: 18px;
          background: var(--gold);
          color: white;
          font-size: 10px;
          font-weight: 700;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .nav-mobile-toggle {
          display: none;
          width: 40px;
          height: 40px;
          align-items: center;
          justify-content: center;
          color: var(--noir);
          border-radius: 8px;
          transition: var(--transition);
        }

        .navbar:not(.scrolled) .nav-mobile-toggle { color: white; }

        /* Mobile Menu */
        .mobile-menu {
          position: fixed;
          top: 0;
          left: 0;
          bottom: 0;
          width: 300px;
          background: var(--cream);
          z-index: 1100;
          transform: translateX(-100%);
          transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 8px 0 40px rgba(0,0,0,0.1);
        }

        .mobile-menu.open { transform: translateX(0); }

        .mobile-menu-inner {
          padding: 32px 24px;
          height: 100%;
          display: flex;
          flex-direction: column;
          gap: 32px;
        }

        .mobile-logo {
          display: flex;
          align-items: baseline;
          gap: 2px;
          padding-bottom: 24px;
          border-bottom: 1px solid var(--border);
        }

        .mobile-menu ul {
          list-style: none;
          display: flex;
          flex-direction: column;
          gap: 4px;
          flex: 1;
        }

        .mobile-link {
          display: block;
          padding: 14px 16px;
          font-size: 15px;
          font-weight: 500;
          color: var(--text-secondary);
          border-radius: var(--radius);
          letter-spacing: 0.05em;
          transition: var(--transition);
        }

        .mobile-link:hover, .mobile-link.active {
          background: rgba(201, 168, 76, 0.08);
          color: var(--gold);
          padding-left: 24px;
        }

        .mobile-footer {
          display: flex;
          flex-direction: column;
          gap: 8px;
          padding-top: 24px;
          border-top: 1px solid var(--border);
          font-size: 13px;
          color: var(--text-muted);
        }

        .mobile-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.4);
          z-index: 1099;
        }

        @media (max-width: 900px) {
          .nav-links { display: none; }
          .nav-mobile-toggle { display: flex; }
        }

        @media (max-width: 600px) {
          .logo-j { font-size: 26px; }
          .logo-text { font-size: 20px; }
          .logo-fashion { font-size: 8px; }
        }
      `}</style>
    </>
  );
}
