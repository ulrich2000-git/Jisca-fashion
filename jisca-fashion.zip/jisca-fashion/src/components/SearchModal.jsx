import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { products, formatPrice } from '../data/products';

export default function SearchModal({ isOpen, onClose }) {
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setQuery('');
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const results = query.trim().length > 1
    ? products.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.description.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 6)
    : [];

  const suggestions = ['Robe Wax', 'Pagne Bogolan', 'Bijoux', 'Sacs', 'Chaussures', 'Kente'];

  return (
    <>
      <div className={`search-backdrop ${isOpen ? 'open' : ''}`} onClick={onClose} />
      <div className={`search-modal ${isOpen ? 'open' : ''}`}>
        <div className="search-inner">
          <div className="search-bar">
            <Search size={20} className="search-icon" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Rechercher un produit, une catégorie..."
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
            {query && (
              <button className="clear-btn" onClick={() => setQuery('')}>
                <X size={16} />
              </button>
            )}
            <button className="close-search" onClick={onClose}>
              <X size={20} />
            </button>
          </div>

          <div className="search-body">
            {query.trim().length < 2 && (
              <div className="search-suggestions">
                <p className="suggest-label">Recherches populaires</p>
                <div className="suggest-tags">
                  {suggestions.map(s => (
                    <button key={s} className="suggest-tag" onClick={() => setQuery(s)}>
                      {s}
                    </button>
                  ))}
                </div>
                <p className="suggest-label" style={{ marginTop: '28px' }}>Tendances</p>
                <div className="trending-products">
                  {products.slice(0, 3).map(p => (
                    <Link key={p.id} to={`/produit/${p.id}`} className="trending-item" onClick={onClose}>
                      <img src={p.image} alt={p.name} />
                      <div>
                        <p>{p.name}</p>
                        <span>{formatPrice(p.price)}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {query.trim().length >= 2 && (
              <div className="search-results">
                {results.length === 0 ? (
                  <div className="no-search-results">
                    <p>Aucun résultat pour "<strong>{query}</strong>"</p>
                    <span>Essayez avec d'autres mots-clés</span>
                  </div>
                ) : (
                  <>
                    <p className="results-label">{results.length} résultat{results.length > 1 ? 's' : ''} pour "{query}"</p>
                    <div className="result-list">
                      {results.map(p => (
                        <Link key={p.id} to={`/produit/${p.id}`} className="result-item" onClick={onClose}>
                          <img src={p.image} alt={p.name} />
                          <div className="result-info">
                            <p>{p.name}</p>
                            <span className="result-cat">{p.category}</span>
                          </div>
                          <strong>{formatPrice(p.price)}</strong>
                          <ArrowRight size={14} className="result-arrow" />
                        </Link>
                      ))}
                    </div>
                    <Link to={`/boutique?q=${query}`} className="see-all-results" onClick={onClose}>
                      Voir tous les résultats <ArrowRight size={14} />
                    </Link>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .search-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(10,8,6,0.6);
          z-index: 1299;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease;
          backdrop-filter: blur(4px);
        }
        .search-backdrop.open { opacity: 1; pointer-events: all; }

        .search-modal {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 1300;
          background: white;
          transform: translateY(-100%);
          transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 20px 60px rgba(0,0,0,0.2);
          max-height: 80vh;
          display: flex;
          flex-direction: column;
        }
        .search-modal.open { transform: translateY(0); }

        .search-inner { display: flex; flex-direction: column; max-width: 800px; margin: 0 auto; width: 100%; padding: 0 24px; }

        .search-bar {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 20px 0;
          border-bottom: 2px solid var(--gold);
        }

        .search-icon { color: var(--gold); flex-shrink: 0; }

        .search-bar input {
          flex: 1;
          font-size: 20px;
          font-family: var(--font-body);
          color: var(--text-primary);
          border: none;
          outline: none;
          background: transparent;
        }
        .search-bar input::placeholder { color: var(--text-muted); }

        .clear-btn, .close-search {
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: var(--text-muted);
          transition: var(--transition);
          flex-shrink: 0;
        }
        .clear-btn:hover, .close-search:hover { background: var(--cream-dark); color: var(--text-primary); }

        .close-search { margin-left: 8px; }

        .search-body { overflow-y: auto; padding: 28px 0; }

        .suggest-label {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: var(--text-muted);
          margin-bottom: 14px;
        }

        .suggest-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 4px; }

        .suggest-tag {
          padding: 8px 16px;
          background: var(--cream-dark);
          border: 1px solid var(--border);
          border-radius: 20px;
          font-size: 13px;
          color: var(--text-secondary);
          transition: var(--transition);
        }
        .suggest-tag:hover { background: var(--gold); border-color: var(--gold); color: white; }

        .trending-products { display: flex; flex-direction: column; gap: 12px; }

        .trending-item {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 10px;
          border-radius: var(--radius);
          transition: var(--transition);
        }
        .trending-item:hover { background: var(--cream-dark); }
        .trending-item img { width: 48px; height: 56px; object-fit: cover; border-radius: var(--radius); }
        .trending-item p { font-size: 14px; font-weight: 500; color: var(--text-primary); margin-bottom: 2px; }
        .trending-item span { font-size: 13px; color: var(--gold-dark); font-weight: 600; }

        .results-label {
          font-size: 12px;
          color: var(--text-muted);
          margin-bottom: 16px;
          padding: 0 4px;
        }

        .result-list { display: flex; flex-direction: column; gap: 2px; margin-bottom: 20px; }

        .result-item {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 12px;
          border-radius: var(--radius);
          transition: var(--transition);
        }
        .result-item:hover { background: var(--cream-dark); }
        .result-item img { width: 52px; height: 60px; object-fit: cover; border-radius: var(--radius); flex-shrink: 0; }
        .result-info { flex: 1; }
        .result-info p { font-size: 14px; font-weight: 500; color: var(--text-primary); }
        .result-cat { font-size: 11px; color: var(--text-muted); text-transform: capitalize; }
        .result-item strong { font-size: 14px; color: var(--gold-dark); flex-shrink: 0; }
        .result-arrow { color: var(--text-muted); flex-shrink: 0; opacity: 0; transition: var(--transition); }
        .result-item:hover .result-arrow { opacity: 1; }

        .no-search-results { text-align: center; padding: 40px 0; }
        .no-search-results p { font-size: 16px; color: var(--text-secondary); margin-bottom: 8px; }
        .no-search-results span { font-size: 13px; color: var(--text-muted); }

        .see-all-results {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          font-weight: 600;
          color: var(--gold);
          text-transform: uppercase;
          letter-spacing: 0.06em;
          transition: var(--transition);
        }
        .see-all-results:hover { gap: 10px; }

        @media (max-width: 640px) {
          .search-bar input { font-size: 16px; }
          .search-inner { padding: 0 16px; }
        }
      `}</style>
    </>
  );
}
