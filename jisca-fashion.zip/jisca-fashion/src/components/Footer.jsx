import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, MapPin, Phone, Mail, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-top container">
        <div className="footer-brand">
          <div className="footer-logo">
            <span className="logo-j">J</span>
            <span className="logo-text">isca</span>
            <span className="logo-fashion">FASHION</span>
          </div>
          <p className="footer-tagline">
            L'élégance africaine au service de votre style. Découvrez l'art de la mode au Bénin.
          </p>
          <div className="footer-social">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="social-btn">
              <Instagram size={18} />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="social-btn">
              <Facebook size={18} />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-btn">
              <Twitter size={18} />
            </a>
          </div>
        </div>

        <div className="footer-links">
          <h4>Navigation</h4>
          <ul>
            <li><Link to="/">Accueil</Link></li>
            <li><Link to="/boutique">Boutique</Link></li>
            <li><Link to="/collections">Collections</Link></li>
            <li><Link to="/a-propos">À Propos</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        <div className="footer-links">
          <h4>Catégories</h4>
          <ul>
            <li><Link to="/boutique?cat=robes">Robes</Link></li>
            <li><Link to="/boutique?cat=pagne">Pagne & Wax</Link></li>
            <li><Link to="/boutique?cat=sacs">Sacs</Link></li>
            <li><Link to="/boutique?cat=bijoux">Bijoux</Link></li>
            <li><Link to="/boutique?cat=chaussures">Chaussures</Link></li>
          </ul>
        </div>

        <div className="footer-contact">
          <h4>Contact</h4>
          <div className="contact-items">
            <div className="contact-item">
              <MapPin size={16} />
              <span>Rue du Commerce, Cotonou, Bénin</span>
            </div>
            <div className="contact-item">
              <Phone size={16} />
              <span>+229 97 XX XX XX</span>
            </div>
            <div className="contact-item">
              <Mail size={16} />
              <span>contact@jiscafashion.bj</span>
            </div>
          </div>
          <div className="footer-hours">
            <p>Lun–Sam : 08h00 – 20h00</p>
            <p>Dimanche : 10h00 – 18h00</p>
          </div>
        </div>
      </div>

      <div className="footer-newsletter container">
        <div className="newsletter-inner">
          <div>
            <h3>Restez informée</h3>
            <p>Abonnez-vous à notre newsletter pour recevoir nos dernières collections et offres exclusives.</p>
          </div>
          <form className="newsletter-form" onSubmit={(e) => e.preventDefault()}>
            <input type="email" placeholder="Votre adresse email" required />
            <button type="submit">S'abonner</button>
          </form>
        </div>
      </div>

      <div className="footer-bottom container">
        <p>© 2024 Jisca Fashion. Tous droits réservés.</p>
        <p className="made-with">Fait avec <Heart size={12} fill="currentColor" /> au Bénin</p>
        <div className="footer-legal">
          <Link to="/confidentialite">Confidentialité</Link>
          <Link to="/cgv">CGV</Link>
        </div>
      </div>

      <style>{`
        .footer {
          background: var(--noir);
          color: rgba(255,255,255,0.7);
          padding-top: 72px;
        }

        .footer-top {
          display: grid;
          grid-template-columns: 2fr 1fr 1fr 1.5fr;
          gap: 48px;
          padding-bottom: 56px;
          border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .footer-logo {
          display: flex;
          align-items: baseline;
          gap: 2px;
          margin-bottom: 16px;
        }

        .footer-logo .logo-j {
          font-family: var(--font-display);
          font-size: 32px;
          font-weight: 700;
          color: var(--gold);
          font-style: italic;
        }

        .footer-logo .logo-text {
          font-family: var(--font-display);
          font-size: 24px;
          font-weight: 400;
          color: white;
          font-style: italic;
        }

        .footer-logo .logo-fashion {
          font-family: var(--font-body);
          font-size: 8px;
          font-weight: 600;
          letter-spacing: 0.25em;
          color: var(--gold);
          margin-left: 6px;
          text-transform: uppercase;
        }

        .footer-tagline {
          font-size: 14px;
          line-height: 1.7;
          margin-bottom: 24px;
          max-width: 280px;
        }

        .footer-social {
          display: flex;
          gap: 8px;
        }

        .social-btn {
          width: 38px;
          height: 38px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 50%;
          color: rgba(255,255,255,0.7);
          transition: var(--transition);
        }

        .social-btn:hover {
          border-color: var(--gold);
          color: var(--gold);
          background: rgba(201, 168, 76, 0.1);
        }

        .footer-links h4, .footer-contact h4 {
          font-family: var(--font-body);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: var(--gold);
          margin-bottom: 20px;
        }

        .footer-links ul {
          list-style: none;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .footer-links ul a {
          font-size: 14px;
          color: rgba(255,255,255,0.6);
          transition: var(--transition);
        }

        .footer-links ul a:hover { color: white; padding-left: 4px; }

        .contact-items {
          display: flex;
          flex-direction: column;
          gap: 12px;
          margin-bottom: 20px;
        }

        .contact-item {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          font-size: 13px;
          line-height: 1.5;
        }

        .contact-item svg { flex-shrink: 0; color: var(--gold); margin-top: 2px; }

        .footer-hours {
          font-size: 12px;
          color: rgba(255,255,255,0.4);
          line-height: 1.8;
        }

        .footer-newsletter {
          padding: 40px 0;
          border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .newsletter-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
        }

        .newsletter-inner h3 {
          font-family: var(--font-display);
          font-size: 26px;
          font-weight: 400;
          color: white;
          margin-bottom: 6px;
        }

        .newsletter-inner p {
          font-size: 13px;
          max-width: 380px;
        }

        .newsletter-form {
          display: flex;
          gap: 0;
          flex-shrink: 0;
          border-radius: var(--radius);
          overflow: hidden;
        }

        .newsletter-form input {
          padding: 13px 20px;
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          border-right: none;
          color: white;
          font-size: 14px;
          width: 280px;
          outline: none;
          transition: var(--transition);
        }

        .newsletter-form input::placeholder { color: rgba(255,255,255,0.35); }
        .newsletter-form input:focus { background: rgba(255,255,255,0.12); border-color: var(--gold); }

        .newsletter-form button {
          padding: 13px 24px;
          background: var(--gold);
          color: white;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.06em;
          white-space: nowrap;
          transition: var(--transition);
        }

        .newsletter-form button:hover { background: var(--gold-dark); }

        .footer-bottom {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 0;
          font-size: 12px;
          color: rgba(255,255,255,0.4);
        }

        .made-with {
          display: flex;
          align-items: center;
          gap: 4px;
          color: rgba(255,255,255,0.3);
        }
        .made-with svg { color: var(--gold); }

        .footer-legal {
          display: flex;
          gap: 20px;
        }

        .footer-legal a { color: rgba(255,255,255,0.4); transition: var(--transition); }
        .footer-legal a:hover { color: white; }

        @media (max-width: 1024px) {
          .footer-top { grid-template-columns: 1fr 1fr; gap: 36px; }
          .footer-brand { grid-column: 1 / -1; }
          .newsletter-inner { flex-direction: column; align-items: flex-start; }
          .newsletter-form input { width: 220px; }
        }

        @media (max-width: 640px) {
          .footer-top { grid-template-columns: 1fr; gap: 32px; }
          .footer-bottom { flex-direction: column; gap: 8px; text-align: center; }
          .newsletter-form { flex-direction: column; }
          .newsletter-form input { width: 100%; border-right: 1px solid rgba(255,255,255,0.15); border-bottom: none; border-radius: var(--radius) var(--radius) 0 0; }
          .newsletter-form button { border-radius: 0 0 var(--radius) var(--radius); }
        }
      `}</style>
    </footer>
  );
}
