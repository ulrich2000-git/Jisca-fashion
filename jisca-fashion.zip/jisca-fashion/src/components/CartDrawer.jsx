import React from 'react';
import { X, Plus, Minus, ShoppingBag, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../data/products';

export default function CartDrawer({ isOpen, onClose }) {
  const { items, dispatch, totalItems, totalPrice } = useCart();

  const updateQty = (item, delta) => {
    dispatch({
      type: 'UPDATE_QUANTITY',
      payload: { id: item.id, selectedSize: item.selectedSize, selectedColor: item.selectedColor, quantity: item.quantity + delta }
    });
  };

  const remove = (item) => {
    dispatch({ type: 'REMOVE_ITEM', payload: { id: item.id, selectedSize: item.selectedSize, selectedColor: item.selectedColor } });
  };

  return (
    <>
      <div className={`cart-overlay ${isOpen ? 'open' : ''}`} onClick={onClose} />
      <div className={`cart-drawer ${isOpen ? 'open' : ''}`}>
        <div className="cart-header">
          <div>
            <h2>Mon Panier</h2>
            {totalItems > 0 && <p>{totalItems} article{totalItems > 1 ? 's' : ''}</p>}
          </div>
          <button className="cart-close" onClick={onClose}><X size={20} /></button>
        </div>

        <div className="cart-body">
          {items.length === 0 ? (
            <div className="cart-empty">
              <ShoppingBag size={48} strokeWidth={1} />
              <h3>Votre panier est vide</h3>
              <p>Découvrez nos belles collections</p>
              <Link to="/boutique" className="btn-gold" onClick={onClose}>
                Voir la boutique
              </Link>
            </div>
          ) : (
            <div className="cart-items">
              {items.map((item, idx) => (
                <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}-${idx}`} className="cart-item">
                  <div className="cart-item-img">
                    <img src={item.image} alt={item.name} />
                  </div>
                  <div className="cart-item-info">
                    <h4>{item.name}</h4>
                    {item.selectedSize && <span className="cart-item-meta">Taille: {item.selectedSize}</span>}
                    {item.selectedColor && <span className="cart-item-meta">Couleur: {item.selectedColor}</span>}
                    <div className="cart-item-bottom">
                      <div className="qty-control">
                        <button onClick={() => updateQty(item, -1)}><Minus size={12} /></button>
                        <span>{item.quantity}</span>
                        <button onClick={() => updateQty(item, 1)}><Plus size={12} /></button>
                      </div>
                      <span className="item-price">{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  </div>
                  <button className="item-remove" onClick={() => remove(item)}><Trash2 size={15} /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="cart-footer">
            <div className="cart-total">
              <span>Total</span>
              <span className="total-price">{formatPrice(totalPrice)}</span>
            </div>
            <p className="cart-note">Livraison calculée à la commande</p>
            <Link to="/commande" className="btn-gold checkout-btn" onClick={onClose}>
              Passer commande
            </Link>
            <button className="btn-outline" onClick={onClose}>
              Continuer mes achats
            </button>
          </div>
        )}
      </div>

      <style>{`
        .cart-overlay {
          position: fixed;
          inset: 0;
          background: rgba(10, 8, 6, 0.5);
          z-index: 1199;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease;
          backdrop-filter: blur(4px);
        }
        .cart-overlay.open { opacity: 1; pointer-events: all; }

        .cart-drawer {
          position: fixed;
          top: 0;
          right: 0;
          bottom: 0;
          width: 420px;
          max-width: 100vw;
          background: var(--cream);
          z-index: 1200;
          display: flex;
          flex-direction: column;
          transform: translateX(100%);
          transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: -20px 0 60px rgba(0,0,0,0.15);
        }
        .cart-drawer.open { transform: translateX(0); }

        .cart-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          padding: 28px 28px 20px;
          border-bottom: 1px solid var(--border);
        }

        .cart-header h2 {
          font-size: 24px;
          font-family: var(--font-display);
          font-weight: 500;
        }
        .cart-header p {
          font-size: 12px;
          color: var(--text-muted);
          margin-top: 2px;
          letter-spacing: 0.05em;
        }

        .cart-close {
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: var(--text-secondary);
          transition: var(--transition);
        }
        .cart-close:hover { background: var(--cream-dark); color: var(--noir); }

        .cart-body {
          flex: 1;
          overflow-y: auto;
          padding: 20px 28px;
        }

        .cart-empty {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100%;
          gap: 16px;
          text-align: center;
          color: var(--text-muted);
          padding: 40px 0;
        }
        .cart-empty h3 { font-family: var(--font-display); font-size: 22px; color: var(--text-primary); font-weight: 400; }
        .cart-empty p { font-size: 14px; }

        .cart-items { display: flex; flex-direction: column; gap: 16px; }

        .cart-item {
          display: flex;
          gap: 14px;
          padding: 16px;
          background: white;
          border-radius: var(--radius-lg);
          position: relative;
          border: 1px solid var(--border);
          transition: var(--transition);
        }
        .cart-item:hover { box-shadow: var(--shadow-gold); }

        .cart-item-img {
          width: 72px;
          height: 80px;
          border-radius: var(--radius);
          overflow: hidden;
          flex-shrink: 0;
        }
        .cart-item-img img { width: 100%; height: 100%; object-fit: cover; }

        .cart-item-info { flex: 1; min-width: 0; }
        .cart-item-info h4 { font-size: 14px; font-weight: 500; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .cart-item-meta { font-size: 11px; color: var(--text-muted); display: block; }

        .cart-item-bottom {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 10px;
        }

        .qty-control {
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--cream-dark);
          border-radius: 20px;
          padding: 4px 8px;
        }
        .qty-control button {
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: var(--text-secondary);
          transition: var(--transition);
        }
        .qty-control button:hover { background: var(--gold); color: white; }
        .qty-control span { font-size: 13px; font-weight: 600; min-width: 16px; text-align: center; }

        .item-price { font-size: 14px; font-weight: 600; color: var(--gold-dark); }

        .item-remove {
          position: absolute;
          top: 10px;
          right: 10px;
          color: var(--text-muted);
          transition: var(--transition);
          padding: 4px;
        }
        .item-remove:hover { color: #e53e3e; }

        .cart-footer {
          padding: 20px 28px 28px;
          border-top: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .cart-total {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 15px;
          font-weight: 500;
        }
        .total-price { font-family: var(--font-display); font-size: 22px; color: var(--gold-dark); }

        .cart-note { font-size: 11px; color: var(--text-muted); text-align: center; margin: -4px 0; }

        .btn-gold {
          display: block;
          text-align: center;
          padding: 14px 24px;
          background: var(--gold);
          color: white;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border-radius: var(--radius);
          transition: var(--transition);
          border: 2px solid var(--gold);
        }
        .btn-gold:hover { background: var(--gold-dark); border-color: var(--gold-dark); transform: translateY(-1px); box-shadow: 0 4px 16px rgba(201, 168, 76, 0.3); }

        .btn-outline {
          display: block;
          text-align: center;
          padding: 12px 24px;
          background: transparent;
          color: var(--text-secondary);
          font-size: 12px;
          font-weight: 500;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          border-radius: var(--radius);
          border: 1px solid var(--border);
          transition: var(--transition);
          width: 100%;
        }
        .btn-outline:hover { border-color: var(--gold); color: var(--gold); }

        .checkout-btn { width: 100%; }

        @media (max-width: 480px) {
          .cart-drawer { width: 100vw; }
          .cart-header, .cart-body, .cart-footer { padding-left: 20px; padding-right: 20px; }
        }
      `}</style>
    </>
  );
}
