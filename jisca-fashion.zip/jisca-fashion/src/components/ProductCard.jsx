import React, { useState } from 'react';
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../data/products';
import toast from 'react-hot-toast';

export default function ProductCard({ product }) {
  const [wished, setWished] = useState(false);
  const [hovered, setHovered] = useState(false);
  const { dispatch } = useCart();

  const addToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch({
      type: 'ADD_ITEM',
      payload: { ...product, selectedSize: product.sizes[0], selectedColor: product.colors[0] }
    });
    toast.success(`${product.name} ajouté au panier !`, {
      icon: '🛍️',
      style: { fontFamily: 'DM Sans, sans-serif', fontSize: '14px' }
    });
  };

  const toggleWish = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setWished(!wished);
    toast(wished ? 'Retiré des favoris' : 'Ajouté aux favoris ❤️', {
      style: { fontFamily: 'DM Sans, sans-serif', fontSize: '14px' }
    });
  };

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null;

  return (
    <Link to={`/produit/${product.id}`} className="product-card" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
      <div className="product-img-wrap">
        <img
          src={product.images?.[hovered && product.images.length > 1 ? 1 : 0] || product.image}
          alt={product.name}
          className="product-img"
        />

        {!product.inStock && <div className="out-of-stock">Rupture de stock</div>}

        <div className="product-badges">
          {product.badge && <span className="badge">{product.badge}</span>}
          {discount && <span className="badge discount">-{discount}%</span>}
        </div>

        <button className={`wish-btn ${wished ? 'active' : ''}`} onClick={toggleWish}>
          <Heart size={16} fill={wished ? 'currentColor' : 'none'} />
        </button>

        <div className="product-actions">
          {product.inStock && (
            <button className="action-btn add-cart" onClick={addToCart}>
              <ShoppingBag size={16} />
              <span>Ajouter</span>
            </button>
          )}
          <Link to={`/produit/${product.id}`} className="action-btn view-btn" onClick={(e) => e.stopPropagation()}>
            <Eye size={16} />
            <span>Voir</span>
          </Link>
        </div>
      </div>

      <div className="product-info">
        <div className="product-rating">
          <div className="stars">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={11} fill={i < Math.floor(product.rating) ? '#C9A84C' : 'none'} stroke="#C9A84C" />
            ))}
          </div>
          <span className="review-count">({product.reviews})</span>
        </div>

        <h3 className="product-name">{product.name}</h3>

        <div className="product-pricing">
          <span className="price">{formatPrice(product.price)}</span>
          {product.originalPrice && (
            <span className="original-price">{formatPrice(product.originalPrice)}</span>
          )}
        </div>
      </div>

      <style>{`
        .product-card {
          display: block;
          text-decoration: none;
          color: inherit;
          background: white;
          border-radius: var(--radius-lg);
          overflow: hidden;
          border: 1px solid var(--border);
          transition: var(--transition);
          position: relative;
          group: true;
        }

        .product-card:hover {
          transform: translateY(-6px);
          box-shadow: var(--shadow-dark);
          border-color: transparent;
        }

        .product-img-wrap {
          position: relative;
          aspect-ratio: 3/4;
          overflow: hidden;
          background: var(--cream-dark);
        }

        .product-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .product-card:hover .product-img { transform: scale(1.05); }

        .out-of-stock {
          position: absolute;
          inset: 0;
          background: rgba(10, 8, 6, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 600;
          color: white;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          z-index: 2;
        }

        .product-badges {
          position: absolute;
          top: 12px;
          left: 12px;
          display: flex;
          flex-direction: column;
          gap: 6px;
          z-index: 3;
        }

        .badge {
          padding: 4px 10px;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border-radius: 20px;
          background: var(--noir);
          color: white;
        }

        .badge.discount {
          background: var(--gold);
          color: white;
        }

        .wish-btn {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 34px;
          height: 34px;
          background: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--text-muted);
          transition: var(--transition);
          z-index: 3;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .wish-btn:hover, .wish-btn.active { color: #e53e3e; transform: scale(1.1); }
        .wish-btn.active { color: #e53e3e; }

        .product-actions {
          position: absolute;
          bottom: -60px;
          left: 0;
          right: 0;
          display: flex;
          gap: 8px;
          padding: 12px;
          transition: bottom 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          z-index: 3;
        }

        .product-card:hover .product-actions { bottom: 0; }

        .action-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 10px;
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
          border-radius: var(--radius);
          transition: var(--transition);
          backdrop-filter: blur(10px);
        }

        .add-cart {
          background: var(--gold);
          color: white;
          border: none;
        }
        .add-cart:hover { background: var(--gold-dark); }

        .view-btn {
          background: rgba(255,255,255,0.9);
          color: var(--noir);
          text-decoration: none;
          flex: 0 0 auto;
          padding: 10px 14px;
        }
        .view-btn:hover { background: white; }

        .product-info {
          padding: 16px 16px 18px;
        }

        .product-rating {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-bottom: 6px;
        }

        .stars { display: flex; gap: 2px; }

        .review-count {
          font-size: 11px;
          color: var(--text-muted);
        }

        .product-name {
          font-family: var(--font-display);
          font-size: 17px;
          font-weight: 500;
          color: var(--text-primary);
          margin-bottom: 8px;
          line-height: 1.3;
        }

        .product-pricing {
          display: flex;
          align-items: baseline;
          gap: 8px;
        }

        .price {
          font-size: 16px;
          font-weight: 600;
          color: var(--gold-dark);
        }

        .original-price {
          font-size: 13px;
          color: var(--text-muted);
          text-decoration: line-through;
        }
      `}</style>
    </Link>
  );
}
