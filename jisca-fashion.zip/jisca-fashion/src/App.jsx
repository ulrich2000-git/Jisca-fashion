import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { CartProvider } from './context/CartContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import SearchModal from './components/SearchModal';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CollectionsPage from './pages/CollectionsPage';
import CheckoutPage from './pages/CheckoutPage';
import { AboutPage, ContactPage } from './pages/OtherPages';

// Scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
}

// 404 Page
function NotFoundPage() {
  return (
    <div style={{ textAlign: 'center', padding: '200px 24px', minHeight: '60vh' }}>
      <p style={{ fontSize: '80px', marginBottom: '24px' }}>404</p>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '36px', fontWeight: 400, fontStyle: 'italic', marginBottom: '16px' }}>
        Page introuvable
      </h2>
      <p style={{ color: 'var(--text-muted)', marginBottom: '32px' }}>
        Cette page n'existe pas ou a été déplacée.
      </p>
      <a href="/" style={{ display: 'inline-block', padding: '14px 32px', background: 'var(--gold)', color: 'white', borderRadius: '4px', fontWeight: 600, fontSize: '14px' }}>
        Retour à l'accueil
      </a>
    </div>
  );
}

function AppContent() {
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  // Close cart/search on ESC
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') {
        setCartOpen(false);
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  // Prevent body scroll when drawer is open
  useEffect(() => {
    if (cartOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [cartOpen]);

  return (
    <div className="app">
      <ScrollToTop />
      <Navbar
        onCartOpen={() => setCartOpen(true)}
        onSearchOpen={() => setSearchOpen(true)}
      />
      <CartDrawer isOpen={cartOpen} onClose={() => setCartOpen(false)} />
      <SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />

      <main style={{ paddingTop: isHome ? 0 : 0 }}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/boutique" element={<ShopPage />} />
          <Route path="/produit/:id" element={<ProductDetailPage onCartOpen={() => setCartOpen(true)} />} />
          <Route path="/collections" element={<CollectionsPage />} />
          <Route path="/commande" element={<CheckoutPage />} />
          <Route path="/a-propos" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/favoris" element={<ShopPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>

      <Footer />

      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 3000,
          style: {
            fontFamily: 'DM Sans, sans-serif',
            fontSize: '14px',
            borderRadius: '8px',
            background: '#1A1612',
            color: '#FAF7F2',
            border: '1px solid rgba(201,168,76,0.2)',
          },
          success: {
            iconTheme: { primary: '#C9A84C', secondary: '#FAF7F2' },
          },
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </BrowserRouter>
  );
}
