# 🛍️ Jisca Fashion — Boutique de Mode en Ligne

Boutique e-commerce fullstack pour **Jisca Fashion**, basée à Cotonou, Bénin. Application React moderne avec panier persistant, filtre produits, tunnel de commande et interface 100% responsive.

---

## ✨ Fonctionnalités

- **Page d'accueil** — Hero animé, catégories, produits vedettes, bannière promo, témoignages
- **Boutique** — Filtres par catégorie, tri par prix/note, recherche en temps réel
- **Fiche produit** — Galerie images, sélection taille/couleur/quantité, produits similaires
- **Collections** — 3 collections thématiques avec lookbook
- **Panier** — Drawer latéral persistant (localStorage), gestion quantités
- **Tunnel de commande** — 3 étapes : infos → livraison → paiement (Mobile Money, Wave, Cash)
- **Recherche** — Modal avec suggestions et résultats en temps réel
- **À propos & Contact** — Pages institutionnelles complètes
- **Footer** — Newsletter, liens, réseaux sociaux, horaires

---

## 🚀 Déploiement sur Netlify

### Méthode 1 — Drag & Drop (le plus rapide)
1. Exécutez `npm run build`
2. Allez sur [netlify.com](https://app.netlify.com)
3. Glissez-déposez le dossier **`dist/`** dans la zone de dépôt

### Méthode 2 — Via Git (recommandée)
1. Poussez ce projet sur GitHub/GitLab
2. Connectez-le à Netlify via **"Import from Git"**
3. Configurez :
   - **Build command** : `npm run build`
   - **Publish directory** : `dist`
4. Cliquez **Deploy**

### Méthode 3 — Netlify CLI
```bash
npm install -g netlify-cli
netlify login
netlify init
npm run build
netlify deploy --prod --dir=dist
```

---

## 💻 Développement local

```bash
# Installer les dépendances
npm install

# Lancer en mode développement
npm run dev
# → http://localhost:5173

# Build de production
npm run build

# Prévisualiser le build
npm run preview
```

---

## 🏗️ Structure du projet

```
jisca-fashion/
├── public/
│   ├── favicon.svg
│   └── _redirects          # SPA routing Netlify
├── src/
│   ├── components/
│   │   ├── Navbar.jsx       # Navigation avec cart badge
│   │   ├── Footer.jsx       # Footer complet
│   │   ├── CartDrawer.jsx   # Panier latéral
│   │   ├── SearchModal.jsx  # Recherche produits
│   │   └── ProductCard.jsx  # Carte produit
│   ├── context/
│   │   └── CartContext.jsx  # State management panier
│   ├── data/
│   │   └── products.js      # Catalogue produits + données
│   ├── pages/
│   │   ├── HomePage.jsx
│   │   ├── ShopPage.jsx
│   │   ├── ProductDetailPage.jsx
│   │   ├── CollectionsPage.jsx
│   │   ├── CheckoutPage.jsx
│   │   └── OtherPages.jsx   # About + Contact
│   ├── styles/
│   │   └── globals.css
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── vite.config.js
├── netlify.toml             # Config Netlify auto
└── package.json
```

---

## 🛠️ Technologies

| Outil | Usage |
|-------|-------|
| **React 18** | Framework UI |
| **React Router v6** | Navigation SPA |
| **Vite** | Build tool |
| **Lucide React** | Icônes |
| **React Hot Toast** | Notifications |
| **CSS Variables** | Design system |
| **localStorage** | Persistance panier |

---

## 🎨 Design System

- **Couleurs** : Or `#C9A84C`, Noir `#0A0806`, Crème `#FAF7F2`
- **Typographie** : Cormorant Garamond (display) + DM Sans (corps)
- **Responsive** : Mobile-first, breakpoints 480/640/768/1024px

---

## 📱 Paiements supportés

- Mobile Money (MTN MoMo, Moov Money)
- Wave
- Paiement à la livraison (Cash)

> Pour la production, intégrez **FedaPay** ou **CinetPay** pour les paiements en ligne réels au Bénin.

---

## 📞 Contact Jisca Fashion

- 📍 Rue du Commerce, Cotonou, Bénin
- 📞 +229 97 XX XX XX
- 📧 contact@jiscafashion.bj

---

*Développé avec ❤️ pour Jisca Fashion — Cotonou, Bénin*
